<?php
// generate.php - 静态页面生成引擎
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/anchor_store.php';

// 确保 public 目录存在
if (!file_exists(OUTPUT_DIR)) {
    mkdir(OUTPUT_DIR, 0777, true);
}

// Serialize generation so simultaneous requests cannot overwrite template bindings.
$generation_lock = fopen(BASE_DIR . '/data/generate.lock', 'c');
if (!$generation_lock || !flock($generation_lock, LOCK_EX | LOCK_NB)) {
    die('已有生成任务正在运行，请等待完成后再试。');
}
$template_bindings_path = BASE_DIR . '/data/template_bindings.json';
$template_bindings = [];
if (is_file($template_bindings_path)) {
    $template_bindings = json_decode(file_get_contents($template_bindings_path), true);
    if (!is_array($template_bindings)) {
        die('模板绑定文件损坏，请恢复 data/template_bindings.json，勿删除后重新随机生成。');
    }
}

function saveTemplateBindings($path, $bindings) {
    $json = json_encode($bindings, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false || file_put_contents($path . '.tmp', $json) === false ||
        !rename($path . '.tmp', $path)) {
        throw new RuntimeException('Cannot save template bindings');
    }
}

function existingTemplate($pagePath, $templates) {
    if (!is_file($pagePath)) {
        return null;
    }
    if (count($templates) === 1) {
        return $templates[0];
    }
    // Original templates have distinct inline CSS; recover an old page's design.
    preg_match_all('~<style\b[^>]*>(.*?)</style>~is', file_get_contents($pagePath), $pageStyles);
    if (!$pageStyles[1]) {
        return null;
    }
    $matches = [];
    foreach ($templates as $template) {
        preg_match_all('~<style\b[^>]*>(.*?)</style>~is', file_get_contents($template), $styles);
        if ($pageStyles[1] === $styles[1]) {
            $matches[] = $template;
        }
    }
    return count($matches) === 1 ? $matches[0] : null;
}

try {
    // 增加数据库超时时间，防止 locked 报错
    $db = new PDO('sqlite:' . DB_PATH, null, null, [
        PDO::ATTR_TIMEOUT => 20,
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
    // 开启 WAL 模式允许并发读写
    $db->exec('PRAGMA journal_mode=WAL;');
    $stmt = $db->query("SELECT id, title, language, source_url FROM articles");
    $articles = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
    $stmt = null;
    $read_content = $db->prepare('SELECT content FROM articles
        WHERE id = ? AND source_url = ? AND language = ?');
    anchorSchema($db);
    $anchor_assignments = anchorAssignments($db);
} catch (Exception $e) {
    die("数据库连接失败: " . $e->getMessage());
}

$count = 0;
$log = "";
$log_entries = 0;
$log_directory = BASE_DIR . '/data/generation_logs';
if (!is_dir($log_directory) && !mkdir($log_directory, 0700, true) && !is_dir($log_directory)) {
    throw new RuntimeException('Cannot create generation log directory.');
}
$log_path = $log_directory . '/generate_' . gmdate('Ymd_His') . '_' .
    bin2hex(random_bytes(8)) . '.log';
$log_file = fopen($log_path, 'xb');
if (!$log_file) {
    throw new RuntimeException('Cannot create generation log.');
}
register_shutdown_function(function () use ($log_file) {
    $error = error_get_last();
    if (is_resource($log_file)) {
        if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
            fwrite($log_file, "\n[ERROR] " . $error['message'] . "\n");
        }
        fclose($log_file);
    }
});

function generationLog($message) {
    global $log, $log_entries, $log_file;
    $line = html_entity_decode(strip_tags($message), ENT_QUOTES | ENT_HTML5, 'UTF-8') . "\n";
    $offset = 0;
    while ($offset < strlen($line)) {
        $written = fwrite($log_file, substr($line, $offset));
        if ($written === false || $written === 0) {
            throw new RuntimeException('Cannot write generation log.');
        }
        $offset += $written;
    }
    fflush($log_file);
    if ($log_entries < 100) {
        $log .= $message;
    }
    $log_entries++;
}

// 辅助函数：基于字符串生成确定的随机索引 (为了让每篇文章绑定的关键词固定不变)
function getDeterministicIndex($string, $max) {
    if ($max <= 0) return 0;
    $hash = md5($string);
    $num = hexdec(substr($hash, 0, 8)); // 取前8位转成数字
    return $num % $max;
}

// 辅助函数：将关键词转换为 SEO 友好的 URL Slug
function generateSlug($str) {
    // 1. 转小写
    $str = mb_strtolower($str, 'UTF-8');
    // 2. 替换越南语/葡萄牙语等特殊字符为普通英文字母 (解决 404 问题的核心)
    $unwanted_array = array(    
        'Š'=>'S', 'š'=>'s', 'Ž'=>'Z', 'ž'=>'z', 'À'=>'A', 'Á'=>'A', 'Â'=>'A', 'Ã'=>'A', 'Ä'=>'A', 'Å'=>'A', 'Æ'=>'A', 'Ç'=>'C', 'È'=>'E', 'É'=>'E',
        'Ê'=>'E', 'Ë'=>'E', 'Ì'=>'I', 'Í'=>'I', 'Î'=>'I', 'Ï'=>'I', 'Ñ'=>'N', 'Ò'=>'O', 'Ó'=>'O', 'Ô'=>'O', 'Õ'=>'O', 'Ö'=>'O', 'Ø'=>'O', 'Ù'=>'U',
        'Ú'=>'U', 'Û'=>'U', 'Ü'=>'U', 'Ý'=>'Y', 'Þ'=>'B', 'ß'=>'Ss', 'à'=>'a', 'á'=>'a', 'â'=>'a', 'ã'=>'a', 'ä'=>'a', 'å'=>'a', 'æ'=>'a', 'ç'=>'c',
        'è'=>'e', 'é'=>'e', 'ê'=>'e', 'ë'=>'e', 'ì'=>'i', 'í'=>'i', 'î'=>'i', 'ï'=>'i', 'ð'=>'o', 'ñ'=>'n', 'ò'=>'o', 'ó'=>'o', 'ô'=>'o', 'õ'=>'o',
        'ö'=>'o', 'ø'=>'o', 'ù'=>'u', 'ú'=>'u', 'û'=>'u', 'ý'=>'y', 'þ'=>'b', 'ÿ'=>'y',
        // 越南语特有
        'Đ'=>'D', 'đ'=>'d', 'ă'=>'a', 'â'=>'a', 'ê'=>'e', 'ô'=>'o', 'ơ'=>'o', 'ư'=>'u'
    );
    $str = strtr($str, $unwanted_array);
    // 3. 替换非字母数字字符为连字符 (-)
    $str = preg_replace('/[^a-z0-9]+/i', '-', $str);
    // 4. 移除开头和结尾的连字符
    $str = trim($str, '-');
    // 如果全被替换光了，给个默认值
    if (empty($str)) {
        $str = "article";
    }
    return $str;
}

function loadResourceLines($kind, $lang) {
    $path = BASE_DIR . "/data/{$kind}_{$lang}.txt";
    $lines = is_file($path) ? file($path, FILE_IGNORE_NEW_LINES) : [];
    return array_values(array_filter(array_map('trim', $lines), function ($line) {
        return $line !== '';
    }));
}

function htmlText($text) {
    return htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function recoverPublishedFilename($article, $proposed, $manifestEntries, $existingFiles) {
    $id = (int)$article['id'];
    if (isset($manifestEntries[$id])) {
        $entry = $manifestEntries[$id];
        $sameSource = isset($entry['source_url'], $entry['language']) &&
            $entry['source_url'] === $article['source_url'] &&
            $entry['language'] === $article['language'];
        $legacyMatch = !isset($entry['source_url']) && isset($entry['title']) &&
            $entry['title'] === $article['title'];
        if (!$sameSource && !$legacyMatch) {
            throw new RuntimeException('Published URL identity mismatch for article ' . $id);
        }
        return $entry['filename'];
    }
    $files = isset($existingFiles[$id]) ? $existingFiles[$id] : [];
    if (count($files) > 1) {
        throw new RuntimeException('Multiple old URLs for article ' . $id .
            '; restore data/generated_pages.json before generating.');
    }
    if ($files) {
        // Without the manifest, verify the visible news headline before adoption.
        $document = new DOMDocument();
        $previous = libxml_use_internal_errors(true);
        $document->loadHTML('<?xml encoding="UTF-8">' .
            file_get_contents(OUTPUT_DIR . '/' . $files[0]));
        libxml_clear_errors();
        libxml_use_internal_errors($previous);
        $heading = $document->getElementsByTagName('h1')->item(0);
        if (!$heading || trim($heading->textContent) !== trim($article['title'])) {
            throw new RuntimeException('Cannot verify old URL for article ' . $id);
        }
        return $files[0];
    }
    return $proposed;
}

function sourceUrlKey($url, $baseUrl = '') {
    $url = html_entity_decode(trim($url), ENT_QUOTES, 'UTF-8');
    if ($url === '' || $url[0] === '#' || preg_match('~^(?:javascript|mailto|tel|data):~i', $url)) {
        return '';
    }
    if (strpos($url, '//') === 0) {
        $url = 'https:' . $url;
    } elseif (!preg_match('~^https?://~i', $url)) {
        $base = parse_url($baseUrl);
        if (empty($base['host'])) {
            return '';
        }
        $path = $url[0] === '/' ? $url : dirname(isset($base['path']) ? $base['path'] : '/') . '/' . $url;
        $url = 'https://' . $base['host'] . $path;
    }
    $parts = parse_url($url);
    if (!$parts || empty($parts['host']) || !in_array(strtolower($parts['scheme'] ?? ''), ['http', 'https'], true)) {
        return '';
    }
    return strtolower($parts['host']) . (isset($parts['port']) ? ':' . $parts['port'] : '') .
        ($parts['path'] ?? '/') . (isset($parts['query']) ? '?' . $parts['query'] : '');
}

function localizeArticleLinks($content, $sourceUrl, $sourcePages) {
    $document = new DOMDocument('1.0', 'UTF-8');
    $previous = libxml_use_internal_errors(true);
    $document->loadHTML('<?xml encoding="UTF-8"><html><body><div id="news-content-root">' . $content . '</div></body></html>');
    libxml_clear_errors();
    libxml_use_internal_errors($previous);
    $links = [];
    foreach ($document->getElementsByTagName('a') as $link) {
        $links[] = $link;
    }
    foreach ($links as $link) {
        $href = $link->getAttribute('href') ?: $link->getAttribute('attr-href');
        $key = sourceUrlKey($href, $sourceUrl);
        if ($key !== '' && isset($sourcePages[$key])) {
            // Keep the original card title/image, but navigate to the local news.
            while ($link->attributes->length) {
                $link->removeAttributeNode($link->attributes->item(0));
            }
            $link->setAttribute('href', $sourcePages[$key]);
        } else {
            // No local target: retain the content without inventing a destination.
            while ($link->firstChild) {
                $link->parentNode->insertBefore($link->firstChild, $link);
            }
            $link->parentNode->removeChild($link);
        }
    }
    $root = $document->getElementById('news-content-root');
    $result = '';
    foreach ($root->childNodes as $child) {
        $result .= $document->saveHTML($child);
    }
    return $result;
}

// Resolve each article once. Rendering and all links use this same identity.
$resources = [];
$pages = [];
$source_pages = [];
$generated_pages = [];
$public_dir = OUTPUT_DIR;
$db->exec('CREATE TABLE IF NOT EXISTS article_url_bindings (
    article_id INTEGER PRIMARY KEY,
    source_url TEXT NOT NULL,
    language TEXT NOT NULL,
    filename TEXT NOT NULL UNIQUE
)');
$url_bindings = [];
$filename_owners = [];
foreach ($db->query('SELECT * FROM article_url_bindings') as $binding) {
    if (!preg_match('/^[a-z0-9-]+-[0-9]+\.html$/D', $binding['filename'])) {
        throw new RuntimeException('Invalid saved article URL; restore the database backup.');
    }
    $url_bindings[$binding['article_id']] = $binding;
    $filename_owners[$binding['filename']] = (int)$binding['article_id'];
}
$manifest_entries = [];
$manifest_path = BASE_DIR . '/data/generated_pages.json';
if (is_file($manifest_path)) {
    $old_manifest = json_decode(file_get_contents($manifest_path), true);
    if (!is_array($old_manifest) || !isset($old_manifest['pages']) || !is_array($old_manifest['pages'])) {
        throw new RuntimeException('Invalid generated_pages.json; restore it before generating.');
    }
    foreach ($old_manifest['pages'] as $entry) {
        if (!isset($entry['filename']) ||
            !preg_match('/^[a-z0-9-]+-([0-9]+)\.html$/D', $entry['filename'], $match)) {
            throw new RuntimeException('Cannot migrate a published URL without an article ID.');
        }
        $id = (int)$match[1];
        if (isset($manifest_entries[$id])) {
            throw new RuntimeException('Duplicate published URL identity for article ' . $id);
        }
        $manifest_entries[$id] = $entry;
    }
}
$existing_files = [];
if (isset($anchor_only_batch_id) && !isset($old_manifest['pages'])) {
    throw new RuntimeException('Generate the full site first to restore data/generated_pages.json before batch publishing.');
}
foreach (glob(OUTPUT_DIR . '/*.html') as $path) {
    $name = basename($path);
    if (preg_match('/^[a-z0-9-]+-([0-9]+)\.html$/D', $name, $match)) {
        $existing_files[(int)$match[1]][] = $name;
    }
}
$insert_url = $db->prepare('INSERT INTO article_url_bindings
    (article_id, source_url, language, filename) VALUES (?, ?, ?, ?)');
$db->beginTransaction();
try {
foreach ($articles as $item) {
    $language = $item['language'];
    if (!isset($resources[$language])) {
        $resources[$language] = [
            'keywords' => loadResourceLines('keywords', $language),
            'titles' => loadResourceLines('titles', $language),
            'descriptions' => loadResourceLines('descriptions', $language)
        ];
    }
    $key = $item['id'] . $item['title'];
    $values = [];
    foreach (['keywords' => 'kw', 'titles' => 'title', 'descriptions' => 'desc'] as $kind => $suffix) {
        $lines = $resources[$language][$kind];
        // A null description is resolved from this article's body during rendering.
        $fallback = $kind === 'descriptions' ? null : $item['title'];
        $values[$kind] = count($lines) ? $lines[getDeterministicIndex($key . $suffix, count($lines))] : $fallback;
    }
    // A keyword can belong to multiple news items; the ID prevents overwrites.
    $filename = substr(generateSlug($values['keywords']), 0, 120) . '-' . (int)$item['id'] . '.html';
    $id = (int)$item['id'];
    $source_identity = isset($item['source_url']) ? $item['source_url'] : '';
    if ($source_identity === '') {
        throw new RuntimeException('Source identity required to bind URL for article ' . $id);
    }
    if (isset($url_bindings[$id])) {
        $binding = $url_bindings[$id];
        if ($binding['source_url'] !== $source_identity || $binding['language'] !== $language) {
            throw new RuntimeException('Saved URL identity mismatch for article ' . $id .
                '; do not reuse article IDs from another database.');
        }
        $filename = $binding['filename'];
    } else {
        $filename = recoverPublishedFilename($item, $filename, $manifest_entries, $existing_files);
        if (isset($filename_owners[$filename]) || 
            (is_file(OUTPUT_DIR . '/' . $filename) &&
             !in_array($filename, isset($existing_files[$id]) ? $existing_files[$id] : [], true))) {
            throw new RuntimeException('Published filename already occupied: ' . $filename);
        }
        $insert_url->execute([$id, $source_identity, $language, $filename]);
        $filename_owners[$filename] = $id;
    }
    $pages[$item['id']] = [
        'filename' => $filename,
        'title' => $item['title'],
        'language' => $language,
        'keyword' => $values['keywords'],
        'custom_title' => $values['titles'],
        'description' => $values['descriptions']
    ];
    $source_key = sourceUrlKey(isset($item['source_url']) ? $item['source_url'] : '');
    if ($source_key !== '') {
        $source_pages[$source_key] = $filename;
    }
}
$db->commit();
} catch (Throwable $error) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    throw $error;
}

// 开始遍历所有文章进行生成
    foreach ($articles as $article) {
        $anchor_assignment = $anchor_assignments[(int)$article['id']] ?? null;
        if (isset($anchor_only_batch_id) && (!$anchor_assignment ||
            $anchor_assignment['batch_id'] !== $anchor_only_batch_id ||
            $anchor_assignment['status'] === 'success')) {
            continue;
        }
        try {
        if ($anchor_assignment) {
            anchorAssertIdentity($anchor_assignment, $article, $pages[$article['id']]['filename']);
        }
        $lang = $article['language'];
        
        // 动态寻找对应语言的模板文件 (新增随机模板支持)
        $template_dir = BASE_DIR . "/admin/templates/";
        $matching_templates = glob($template_dir . "{$lang}_*.html");
        
        if (empty($matching_templates)) {
             $matching_templates = glob($template_dir . "{$lang}*.html");
        }
        
        $binding_key = (string)$article['id'];
        $source_identity = isset($article['source_url']) ? $article['source_url'] : '';
        $binding = isset($template_bindings[$binding_key]) ? $template_bindings[$binding_key] : null;
        if ($binding !== null) {
            if (!is_array($binding) || !isset($binding['template'], $binding['source_url']) ||
                $binding['source_url'] !== $source_identity ||
                basename($binding['template']) !== $binding['template']) {
                throw new RuntimeException('Invalid template binding for article ' . $binding_key);
            }
            $template_file = $template_dir . $binding['template'];
            if (!is_file($template_file)) {
                throw new RuntimeException('Bound template missing: ' . $binding['template'] . '. Restore it before generating.');
            }
        } elseif (empty($matching_templates)) {
            $template_file = BASE_DIR . "/admin/templates/{$lang}_template.html";
            if (!file_exists($template_file)) {
                if ($anchor_assignment) {
                    throw new RuntimeException('No template for assigned article.');
                }
                generationLog("<span style='color:red;'>[跳过] 找不到 " . htmlText($lang) . " 语言的模板文件</span><br>");
                continue;
            }
        } else {
            $old_page_path = OUTPUT_DIR . '/' . $pages[$article['id']]['filename'];
            $template_file = existingTemplate($old_page_path, $matching_templates);
            if ($template_file === null && is_file($old_page_path)) {
                throw new RuntimeException('Cannot identify existing template for ' .
                    $pages[$article['id']]['filename'] . '. Existing design was not changed.');
            }
            if ($template_file === null) {
                $template_file = $matching_templates[array_rand($matching_templates)];
            }
        }
        if ($binding === null) {
            $template_bindings[$binding_key] = [
                'source_url' => $source_identity,
                'template' => basename($template_file)
            ];
            saveTemplateBindings($template_bindings_path, $template_bindings);
        }
        
        $template_html = file_get_contents($template_file);
        
        $page = $pages[$article['id']];
        $read_content->execute([$article['id'], $article['source_url'], $article['language']]);
        $content = $read_content->fetchColumn();
        $read_content->closeCursor();
        if ($content === false) {
            throw new RuntimeException('Article identity changed or disappeared during generation.');
        }
        $article['content'] = $content ?? '';
        unset($content);
        $random_keyword = $page['keyword'];
        $random_title = $page['custom_title'];
        $random_desc = $page['description'] ?? trim(strip_tags($article['content']));
        $language_rule = isset($seo_config[$lang]) && is_array($seo_config[$lang]) ? $seo_config[$lang] : [];
        $current_filename = $page['filename'];
    // #region debug-point B:filename
    if (getenv('NEWS_DEBUG_URL')) { @file_get_contents(getenv('NEWS_DEBUG_URL'), false, stream_context_create(['http' => ['method' => 'POST', 'header' => 'Content-Type: application/json', 'timeout' => 1, 'content' => json_encode(['sessionId' => 'related-news-mapping', 'runId' => getenv('NEWS_DEBUG_RUN') ?: 'pre-fix', 'hypothesisId' => 'B', 'msg' => '[DEBUG] filename', 'data' => ['id' => $article['id'], 'filename' => $current_filename]])]])); }
    // #endregion

    // ================= 友情链接/内链生成逻辑 =================
    // 每页随机 200-1000 条；不足时只输出现有目标，不重复补足。
    $link_count = rand(200, 1000);
    $footer_links_html = "\n<!-- SEO Internal Links -->\n<div class=\"seo-internal-links\" style=\"margin-top:50px; padding:20px; background:#f9f9f9; border-top:1px solid #eee;\">\n    <ul style=\"list-style:none; padding:0; display:flex; flex-wrap:wrap; gap:15px;\">\n";
    
    // 收集将要用于“相关阅读”的内链数据 (插 3-5 个)
    $related_posts = [];
    $related_count = rand(3, 5);
    
    $candidates = array_values(array_filter($pages, function ($candidate) use ($lang, $current_filename) {
        return $candidate['language'] === $lang && $candidate['filename'] !== $current_filename;
    }));
    shuffle($candidates);
    foreach (array_slice($candidates, 0, $link_count) as $target) {
        $target_url = $target['filename'];
        $target_kw = htmlText($target['keyword']);
        $footer_links_html .= "        <li><a href=\"{$target_url}\" style=\"color:#555;\">{$target_kw}</a></li>\n";
        if (count($related_posts) < $related_count) {
            $related_posts[] = ['url' => $target_url, 'text' => $target['title']];
            // #region debug-point A:related-url
            if (getenv('NEWS_DEBUG_URL')) { @file_get_contents(getenv('NEWS_DEBUG_URL'), false, stream_context_create(['http' => ['method' => 'POST', 'header' => 'Content-Type: application/json', 'timeout' => 1, 'content' => json_encode(['sessionId' => 'related-news-mapping', 'runId' => getenv('NEWS_DEBUG_RUN') ?: 'pre-fix', 'hypothesisId' => 'A', 'msg' => '[DEBUG] related URL', 'data' => ['actual' => $target_url, 'expected' => $target['filename'], 'title' => $target['title']]])]])); }
            // #endregion
        }
    }
    $footer_links_html .= "    </ul>\n</div>\n";
    // =========================================================

    // ================= 正文底部“相关阅读”内链注入 =================
    // Recommendations use the original news title, not the custom SEO title.
    $related_html = "\n<div class=\"related-posts\" style=\"margin-top:40px; padding-top:20px; border-top:2px dashed #eaeaea;\">\n";
    $related_html .= "    <h3 style=\"font-size:18px; color:#333; margin-bottom:15px;\">Tin tức liên quan:</h3>\n";
    $related_html .= "    <ul style=\"list-style-type:disc; padding-left:20px; line-height:1.8;\">\n";
    foreach ($related_posts as $post) {
        $text = htmlText($post['text']);
        $related_html .= "        <li><a href=\"{$post['url']}\" style=\"color:#2980b9; text-decoration:underline;\">{$text}</a></li>\n";
    }
    $related_html .= "    </ul>\n</div>\n";
    if (!$related_posts) {
        $related_html = '';
    }
    
    // ================= 修复图片和外链 =================
    $raw_content = $article['content'];
    
    // （注：图片下载本地化已经在 Python 爬虫端完成，这里不需要再替换为原站路径了，保留本地 uploads 路径即可）
    
    $raw_content = localizeArticleLinks(
        $raw_content,
        isset($article['source_url']) ? $article['source_url'] : '',
        $source_pages
    );
    
    // 将相关阅读直接拼接在文章正文内容的最后面
    // Replace the slot after template variables so literal braces in anchor text survive.
    $anchor_slot = '<!-- fixed-external-anchor-' . bin2hex(random_bytes(16)) . ' -->';
    $processed_content = $raw_content . ($anchor_assignment ? $anchor_slot : '') . $related_html;
    // =========================================================

    // ================= 准备该页面的 TDK =================
        $search = ['{title}', '{keyword}', '{custom_title}', '{custom_desc}', '{article_title}'];
        $replace = [$article['title'], $random_keyword, $random_title, $random_desc, $article['title']];
        
        // 防止未配置该语言时报错
         $title_rule = isset($language_rule['title_rule']) ? $language_rule['title_rule'] : '{article_title}';
         $keywords_rule = isset($language_rule['keywords']) ? $language_rule['keywords'] : '{keyword}';
         $desc_rule = isset($language_rule['desc_rule']) ? $language_rule['desc_rule'] : '{custom_desc}';

        $page_title = str_replace($search, $replace, $title_rule);
        $page_keywords = str_replace($search, $replace, $keywords_rule);
        $page_desc = str_replace($search, $replace, $desc_rule);
    
    // ================= 修复模板中写死的原站外链 =================
    // 防止点击模板的其他栏目跳转到原网站，全部替换为返回首页 (/)
    $template_html = str_replace('https://nicotexfly.vn/', '/', $template_html);
    $template_html = str_replace('https://nicotexfly.vn', '/', $template_html);
    $template_html = str_replace('https://nongnghiephuuco.vn/', '/', $template_html);
    $template_html = str_replace('https://nongnghiephuuco.vn', '/', $template_html);
    // =========================================================
    
        // 渲染模板标签 (增加 {keyword} 等标签，支持在 HTML 模板源码里直接调用当前绑定的专属词)
         // The visible news headline always belongs to this collected article.
        $final_html = str_replace(
            ['{seo_title}', '{seo_keywords}', '{seo_description}', '{article_title}', '{article_content}', '{keyword}', '{custom_title}', '{custom_desc}'],
             [htmlText($page_title), htmlText($page_keywords), htmlText($page_desc), htmlText($article['title']), $processed_content, htmlText($random_keyword), htmlText($random_title), htmlText($random_desc)],
            $template_html
        );
        if ($anchor_assignment) {
            $final_html = str_replace($anchor_slot, anchorMarkup($anchor_assignment), $final_html);
        }
        // #region debug-point C:heading
        if (getenv('NEWS_DEBUG_URL')) { @file_get_contents(getenv('NEWS_DEBUG_URL'), false, stream_context_create(['http' => ['method' => 'POST', 'header' => 'Content-Type: application/json', 'timeout' => 1, 'content' => json_encode(['sessionId' => 'related-news-mapping', 'runId' => getenv('NEWS_DEBUG_RUN') ?: 'pre-fix', 'hypothesisId' => 'C', 'msg' => '[DEBUG] heading/config', 'data' => ['news' => $article['title'], 'heading' => $article['title'], 'ruleType' => gettype($language_rule)]])]])); }
        // #endregion
        
        // ================= 批量统计与跳转注入 =================
        $script_file = BASE_DIR . "/data/global_script.txt";
        $global_script = file_exists($script_file) ? file_get_contents($script_file) : "";
        
        if (!empty($global_script)) {
            // 最好将统计和跳转代码放在 <head> 里执行最快，如果找不到 <head> 则放到最前面
            if (stripos($final_html, '</head>') !== false) {
                $final_html = str_ireplace('</head>', "\n" . $global_script . "\n</head>", $final_html);
            } else {
                $final_html = $global_script . "\n" . $final_html;
            }
        }
        // =========================================================
        
        // 将生成的内链插入到 </body> 标签之前。如果模板里没有 </body>，就直接追加到最后。
        if (stripos($final_html, '</body>') !== false) {
            $final_html = str_ireplace('</body>', $footer_links_html . '</body>', $final_html);
        } else {
            $final_html .= $footer_links_html;
    }
    
    // 生成最终的静态文件，直接输出到 public 目录
    $public_dir = OUTPUT_DIR;
    if (!is_dir($public_dir)) {
        mkdir($public_dir, 0755, true);
    }
    
    // 强制清理文件名中可能存在的隐藏空格、换行符等不可见字符
    $clean_filename = trim($current_filename);
    $output_path = $public_dir . "/" . $clean_filename;
    
    if ($anchor_assignment) {
        anchorVerify($final_html, $anchor_assignment);
    }
    if (file_put_contents($output_path . '.tmp', $final_html) === false ||
        !rename($output_path . '.tmp', $output_path)) {
        throw new RuntimeException("Cannot write article: " . $clean_filename);
    }
    if ($anchor_assignment) {
        $written_html = file_get_contents($output_path);
        if ($written_html === false) {
            throw new RuntimeException('Cannot verify published anchor page.');
        }
        anchorVerify($written_html, $anchor_assignment);
        anchorPublished($db, (int)$article['id'], rtrim(SITE_URL, '/') . '/' . $clean_filename);
    }
    $generated_pages[] = [
        'filename' => $clean_filename,
        'title' => $article['title'],
        'article_id' => (int)$article['id'],
        'source_url' => $article['source_url'],
        'language' => $article['language']
    ];
    generationLog("<span style='color:green;'>[成功] 生成网页 -> <a href='../public/{$clean_filename}' target='_blank'>{$clean_filename}</a></span><br>");
    $last_success_path = $output_path;
    $count++;
        } catch (Throwable $error) {
            if (!$anchor_assignment) {
                throw $error;
            }
            anchorFailed($db, (int)$article['id'], $error->getMessage());
            generationLog('<span style="color:red;">[投放失败] 文章 ' . (int)$article['id'] .
                ': ' . htmlText($error->getMessage()) . '</span><br>');
        } finally {
            // Do not keep the previous body/DOM output while processing the next article.
            unset($article['content'], $raw_content, $processed_content, $final_html,
                $written_html, $random_desc, $page_desc, $replace, $candidates);
        }
} // 结束 foreach ($articles as $article)
try {
    $anchor_exports = anchorExportReady($db, OUTPUT_DIR, BASE_DIR . '/data/anchor_exports');
    if ($anchor_exports) {
        generationLog('<span style="color:blue;">[锚文本] 成功清单已保存，历史 TXT 未覆盖。</span><br>');
    }
} catch (Throwable $error) {
    generationLog('<span style="color:red;">[导出待恢复] ' . htmlText($error->getMessage()) .
        '；投放记录保留，请到外部锚文本后台重试导出。</span><br>');
}

// ================= 生成默认首页 (index.html) =================
// 解决 403 Forbidden 问题
$index_path = $public_dir . "/index.html";
if (is_file($index_path)) {
    generationLog("<span style='color:blue;'>[保留] 首页未覆盖，继续显示原来的文章 -> <a href='../public/index.html' target='_blank'>index.html</a></span><br>");
} elseif (!isset($anchor_only_batch_id) && isset($last_success_path)) {
    // Create only when absent; subsequent runs preserve the homepage exactly.
    if (!copy($last_success_path, $index_path)) {
        throw new RuntimeException('Cannot create homepage');
    }
    generationLog("<span style='color:blue;'>[提示] 成功生成默认首页 -> <a href='../public/index.html' target='_blank'>index.html</a></span><br>");
} else {
    generationLog("<span style='color:red;'>[警告] 无法生成首页，可能没有采集到任何文章。</span><br>");
}
// ==========================================================

// Publish only files successfully written in this generation.
if ($generated_pages) {
    // A batch publishes only its selected articles; preserve the other sitemap entries.
    if (isset($anchor_only_batch_id) && isset($old_manifest['pages'])) {
        $merged_pages = [];
        foreach (array_merge($old_manifest['pages'], $generated_pages) as $entry) {
            if (is_file(OUTPUT_DIR . '/' . $entry['filename'])) {
                $merged_pages[$entry['filename']] = $entry;
            }
        }
        $generated_pages = array_values($merged_pages);
    }
    $manifest = ['site_url' => rtrim(SITE_URL, '/'), 'pages' => $generated_pages];
    $manifest_json = json_encode($manifest, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $manifest_path = BASE_DIR . '/data/generated_pages.json';
    if ($manifest_json === false || file_put_contents($manifest_path . '.tmp', $manifest_json) === false ||
        !rename($manifest_path . '.tmp', $manifest_path)) {
        throw new RuntimeException('Cannot publish generated page manifest');
    }
    $sitemap = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
    $sitemap .= "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";
    foreach (array_merge([['filename' => 'index.html']], $generated_pages) as $entry) {
        $url = htmlspecialchars(rtrim(SITE_URL, '/') . '/' . $entry['filename'], ENT_XML1 | ENT_QUOTES, 'UTF-8');
        $sitemap .= "  <url><loc>{$url}</loc></url>\n";
    }
    $sitemap .= "</urlset>\n";
    if (file_put_contents($public_dir . '/sitemap.xml.tmp', $sitemap) === false ||
        !rename($public_dir . '/sitemap.xml.tmp', $public_dir . '/sitemap.xml')) {
        throw new RuntimeException('Cannot publish sitemap');
    }
}

$peak_memory_mb = round(memory_get_peak_usage(true) / 1048576, 2);
generationLog('[完成] 成功 ' . $count . ' 篇；PHP 峰值内存 ' . $peak_memory_mb . ' MB<br>');
fclose($log_file);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>生成结果 - SEO CMS</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f5f7fa; padding: 40px; }
        .container { background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); max-width: 800px; margin: 0 auto; }
        h1 { color: #2ecc71; }
        .log-box { background: #222; color: #fff; padding: 15px; border-radius: 5px; height: 300px; overflow-y: auto; font-family: monospace; line-height: 1.5; margin: 20px 0; }
        .btn { padding: 10px 20px; background: #3498db; color: #fff; text-decoration: none; border-radius: 4px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>静态页面生成完毕</h1>
        <p>本次共成功生成 <strong><?php echo $count; ?></strong> 个静态 HTML 页面，已保存至 public 目录。</p>
        
        <h3>执行日志：</h3>
        <p>页面最多显示前 100 条；完整日志保存在 <?php echo htmlText('data/generation_logs/' . basename($log_path)); ?>，请通过宝塔文件管理查看。</p>
        <p>PHP 峰值内存：<?php echo $peak_memory_mb; ?> MB</p>
        <div class="log-box">
            <?php echo $log ?: "没有执行任何生成操作。"; ?>
        </div>
        
        <a href="index.php" class="btn">🔙 返回控制台</a>
        <a href="anchors.php" class="btn">外部锚文本与 TXT 下载</a>
        <a href="../public/" target="_blank" class="btn" style="background:#2ecc71;">👁️ 预览生成的站点</a>
    </div>
</body>
</html>

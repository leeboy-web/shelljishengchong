<?php
declare(strict_types=1);
require __DIR__ . '/config.php';
require_once __DIR__ . '/anchor_store.php';
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: same-origin');
header("Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'");
session_name('seo_anchor_admin');
session_set_cookie_params([
    'httponly' => true, 'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'samesite' => 'Strict'
]);
session_start();
$password = require __DIR__ . '/anchor_access.php';
if (!is_string($password) || strlen($password) < 12) {
    http_response_code(503);
    exit('请先在 admin/anchor_access.php 设置至少 12 位私有密码，再打开本页面。');
}
$fingerprint = hash('sha256', $password);
$authenticated = isset($_SESSION['anchor_auth'], $_SESSION['anchor_last_seen']) &&
    hash_equals($fingerprint, $_SESSION['anchor_auth']) &&
    time() - $_SESSION['anchor_last_seen'] < 3600;
if (empty($_SESSION['anchor_csrf'])) {
    $_SESSION['anchor_csrf'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['anchor_csrf'];
$error = '';
$notice = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!is_string($_POST['csrf'] ?? null) || !hash_equals($csrf, $_POST['csrf'])) {
        http_response_code(403);
        exit('请求验证失败，请刷新页面后再试。');
    }
    if (($_POST['action'] ?? '') === 'login') {
        if (is_string($_POST['password'] ?? null) && hash_equals($password, $_POST['password'])) {
            session_regenerate_id(true);
            $_SESSION['anchor_auth'] = $fingerprint;
            $_SESSION['anchor_last_seen'] = time();
            header('Location: anchors.php', true, 303);
            exit;
        }
        http_response_code(403);
        $error = '密码不正确。请通过宝塔限制后台访问 IP，避免公网暴力尝试。';
    } elseif (!$authenticated) {
        http_response_code(403);
        exit('请先登录外部锚文本管理。');
    }
}
if (!$authenticated) {
?>
<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>外部锚文本登录</title><body>
<h1>外部锚文本管理</h1><p><?php echo anchorEscape($error); ?></p>
<form method="post"><input type="hidden" name="csrf" value="<?php echo anchorEscape($csrf); ?>">
<input type="hidden" name="action" value="login">
<label>管理密码 <input type="password" name="password" required autocomplete="current-password"></label>
<button type="submit">登录</button></form></body></html>
<?php
    exit;
}
$_SESSION['anchor_last_seen'] = time();
if (isset($_GET['new_form']) && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $_SESSION['anchor_request_token'] = bin2hex(random_bytes(32));
    header('Location: anchors.php', true, 303);
    exit;
}
if (empty($_SESSION['anchor_request_token'])) {
    $_SESSION['anchor_request_token'] = bin2hex(random_bytes(32));
}
$requestToken = $_SESSION['anchor_request_token'];
session_write_close();
$db = new PDO('sqlite:' . DB_PATH, null, null, [
    PDO::ATTR_TIMEOUT => 20, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
]);
anchorSchema($db);
$exportDirectory = BASE_DIR . '/data/anchor_exports';
if (isset($_GET['download'])) {
    $query = $db->prepare('SELECT * FROM anchor_exports WHERE id = ?');
    $query->execute([is_string($_GET['download']) ? $_GET['download'] : '']);
    $export = $query->fetch(PDO::FETCH_ASSOC);
    if (!$export) {
        http_response_code(404);
        exit('导出文件不存在。');
    }
    // Serve the immutable database snapshot, not a user-selected filesystem path.
    header('Content-Type: text/plain; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $export['filename'] . '"');
    echo $export['payload'];
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lock = fopen(BASE_DIR . '/data/generate.lock', 'c');
    if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) {
        if ($lock) {
            fclose($lock);
        }
        $error = '已有生成或投放任务运行，请等待完成后重试；本次没有新建批次。';
    } else {
        try {
            $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
            if ($action === 'create') {
                $token = $_POST['request_token'] ?? '';
                if (!is_string($token) || !hash_equals($requestToken, $token)) {
                    throw new RuntimeException('表单已过期，请刷新。重复提交请查看历史批次，不要再次新建。');
                }
                $count = filter_var($_POST['count'] ?? '', FILTER_VALIDATE_INT);
                if ($count === false || !is_string($_POST['anchor_text'] ?? null) ||
                    !is_string($_POST['target_url'] ?? null) || ($_POST['confirm'] ?? '') !== 'yes') {
                    throw new RuntimeException('请填写有效数量、锚文本和网址，并勾选确认。');
                }
                $batchId = anchorCreateBatch($db, $token, trim($_POST['anchor_text']),
                    trim($_POST['target_url']), $count, OUTPUT_DIR);
            } elseif ($action === 'run') {
                $batchId = is_string($_POST['batch_id'] ?? null) ? $_POST['batch_id'] : '';
                anchorBatch($db, $batchId);
            } elseif ($action === 'export') {
                anchorExportReady($db, OUTPUT_DIR, $exportDirectory);
                $notice = '已恢复成功清单文件，历史 TXT 不修改。';
            } else {
                throw new RuntimeException('未知操作。');
            }
        } catch (Throwable $exception) {
            $error = $exception->getMessage();
        } finally {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
        if ($error === '' && isset($batchId)) {
            // Batch membership is already fixed; resuming never picks new articles.
            $anchor_only_batch_id = $batchId;
            $db = null;
            header_remove('Content-Security-Policy');
            require __DIR__ . '/generate.php';
            exit;
        }
    }
}
$batches = $db->query('SELECT b.*, COUNT(x.article_id) AS selected,
    COALESCE(SUM(x.status = "success"), 0) AS succeeded,
    COALESCE(SUM(x.status = "failed"), 0) AS failed
    FROM anchor_batches b LEFT JOIN article_anchors x ON x.batch_id = b.id
    GROUP BY b.id ORDER BY b.created_at DESC, b.id DESC LIMIT 100')->fetchAll(PDO::FETCH_ASSOC);
$exports = $db->query('SELECT id, batch_id, filename, created_at FROM anchor_exports
    ORDER BY created_at DESC, id DESC LIMIT 200')->fetchAll(PDO::FETCH_ASSOC);
$failures = $db->query('SELECT article_id, batch_id, error FROM article_anchors
    WHERE status = "failed" ORDER BY article_id DESC LIMIT 100')->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="zh-CN">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>外部锚文本投放</title>
<style>
body{font-family:Arial,sans-serif;background:#f5f7fa;color:#243447;margin:0;padding:24px}
main{max-width:1100px;margin:auto;background:white;padding:24px;border-radius:8px}
label{display:block;margin:16px 0}input[type=text],input[type=url],input[type=number]{box-sizing:border-box;width:100%;max-width:700px;padding:10px}
button{padding:10px 16px;cursor:pointer}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ddd;padding:8px;text-align:left;overflow-wrap:anywhere}
.scroll{overflow-x:auto}.error{color:#a32222}a{color:#165db1}small{display:block;margin:8px 0}
</style></head>
<body><main>
<a href="index.php">返回控制台</a><h1>外部锚文本投放</h1>
<p>完全随机抽取未投放的已生成文章，不按语言、分类或主题筛选。每篇一条，放在正文结尾、相关推荐之前。</p>
<p>已投放文章保留原绑定；本批不足指定数量时按实际数量处理。首页 index.html 不单独投放或更新。</p>
<?php if ($error !== ''): ?><p class="error"><?php echo anchorEscape($error); ?></p><?php endif; ?>
<?php if ($notice !== ''): ?><p><?php echo anchorEscape($notice); ?></p><?php endif; ?>
<form method="post">
<input type="hidden" name="csrf" value="<?php echo anchorEscape($csrf); ?>">
<input type="hidden" name="request_token" value="<?php echo anchorEscape($requestToken); ?>">
<input type="hidden" name="action" value="create">
<label>本批文章数量 <input type="number" name="count" min="1" max="100000" value="100" required></label>
<label>锚文本 <input type="text" name="anchor_text" maxlength="300" required></label>
<label>外部目标网址 <input type="url" name="target_url" placeholder="https://example.com/guide" required></label>
<label><input type="checkbox" name="confirm" value="yes" required> 确认随机抽取，每篇一条，不覆盖历史批次和 TXT。</label>
<button type="submit">创建批次并执行投放</button>
<small>重复提交同一表单不会新建第二批。创建下一批请先打开新的表单。</small>
</form>
<p><a href="anchors.php?new_form=1">打开下一批的新表单</a></p>
<h2>最近 100 个批次</h2><div class="scroll"><table>
<tr><th>批次 / 锚文本</th><th>请求 / 选中</th><th>成功 / 失败 / 待处理</th><th>操作</th></tr>
<?php foreach ($batches as $batch): ?>
<tr><td><?php echo anchorEscape($batch['id']); ?><br><?php echo anchorEscape($batch['anchor_text']); ?><br><?php echo anchorEscape($batch['target_url']); ?></td>
<td><?php echo (int)$batch['requested']; ?> / <?php echo (int)$batch['selected']; ?></td>
<td><?php echo (int)$batch['succeeded']; ?> / <?php echo (int)$batch['failed']; ?> / <?php echo (int)$batch['selected'] - (int)$batch['succeeded'] - (int)$batch['failed']; ?></td>
<td><form method="post"><input type="hidden" name="csrf" value="<?php echo anchorEscape($csrf); ?>">
<input type="hidden" name="action" value="run"><input type="hidden" name="batch_id" value="<?php echo anchorEscape($batch['id']); ?>">
<button type="submit">继续 / 重试本批</button></form></td></tr>
<?php endforeach; ?></table></div>
<h2>最近 200 个 TXT 导出</h2><p>每批成功清单是独立文件，补做成功会另建补充文件；旧文件不修改。更早记录保留在数据库。</p>
<form method="post"><input type="hidden" name="csrf" value="<?php echo anchorEscape($csrf); ?>">
<input type="hidden" name="action" value="export"><button type="submit">重试 / 恢复导出文件</button></form>
<ul><?php foreach ($exports as $export): ?><li>
<a href="?download=<?php echo anchorEscape($export['id']); ?>"><?php echo anchorEscape($export['filename']); ?></a>
</li><?php endforeach; ?></ul>
<h2>失败原因</h2><ul><?php foreach ($failures as $failure): ?>
<li>文章 <?php echo (int)$failure['article_id']; ?>：<?php echo anchorEscape($failure['error']); ?></li>
<?php endforeach; ?></ul>
</main></body></html>

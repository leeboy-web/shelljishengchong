<?php
// index.php - 后台管理首页
require __DIR__ . '/config.php';

$page_size = 50;
$requested_page = filter_var($_GET['page'] ?? 1, FILTER_VALIDATE_INT, [
    'options' => ['min_range' => 1]
]);
$page_number = $requested_page === false ? 1 : $requested_page;
$total_articles = 0;
$total_pages = 1;

// 确保数据库目录存在，以便 Python 端第一次运行时不会报错
if (!file_exists(dirname(DB_PATH))) {
    mkdir(dirname(DB_PATH), 0777, true);
}

// 连接 SQLite 数据库 (如果不存在，PDO 尝试建立)
try {
    // 增加数据库超时时间，防止 locked 报错
    $db = new PDO('sqlite:' . DB_PATH, null, null, [
        PDO::ATTR_TIMEOUT => 20,
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
    
    // 开启 WAL 模式允许并发读写
    $db->exec('PRAGMA journal_mode=WAL;');
    
    // 初始化表结构 (防爬虫还没运行的情况下先打开了后台)
    $db->exec("CREATE TABLE IF NOT EXISTS articles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        content TEXT,
        language TEXT,
        source_url TEXT UNIQUE,
        created_at DATETIME
    )");

    $total_articles = (int)$db->query('SELECT COUNT(*) FROM articles')->fetchColumn();
    $total_pages = max(1, (int)ceil($total_articles / $page_size));
    $page_number = min($page_number, $total_pages);
    // The list never loads article bodies, regardless of database size.
    $stmt = $db->prepare('SELECT id, title, language, source_url, created_at
        FROM articles ORDER BY id DESC LIMIT :limit OFFSET :offset');
    $stmt->bindValue(':limit', $page_size, PDO::PARAM_INT);
    $stmt->bindValue(':offset', ($page_number - 1) * $page_size, PDO::PARAM_INT);
    $stmt->execute();
    $articles = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
} catch (Exception $e) {
    $articles = [];
    $error_msg = "数据库连接失败: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>SEO CMS 后台管理</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 0; background-color: #f5f7fa; color: #333; }
        .header { background-color: #2c3e50; color: #fff; padding: 20px; text-align: center; }
        .container { width: 90%; max-width: 1200px; margin: 20px auto; background: #fff; padding: 20px; box-shadow: 0 0 10px rgba(0,0,0,0.1); border-radius: 8px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        th { background-color: #f8f9fa; font-weight: 600; }
        tr:hover { background-color: #f1f1f1; }
        .btn { display: inline-block; padding: 10px 20px; background: #3498db; color: #fff; text-decoration: none; border-radius: 4px; transition: background 0.3s; }
        .btn:hover { background: #2980b9; }
        .btn-success { background: #2ecc71; }
        .btn-success:hover { background: #27ae60; }
        .action-bar { margin-bottom: 20px; display: flex; gap: 10px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🚀 SEO CMS 自动化内容管理系统</h1>
    </div>
    
    <div class="container">
        <?php if(isset($error_msg)): ?>
            <div style="color: red; margin-bottom: 20px;"><?php echo $error_msg; ?></div>
        <?php endif; ?>

        <div class="action-bar">
            <a href="generate.php" class="btn btn-success">⚡ 一键生成静态网站</a>
            <a href="anchors.php" class="btn">外部锚文本投放 / TXT 下载</a>
            <a href="../public/" target="_blank" class="btn">👁️ 预览 Public 目录</a>
        </div>
        
        <h2>📚 已采集文章库 (共 <?php echo $total_articles; ?> 篇)</h2>
        <nav aria-label="文章分页">
            <p>第 <?php echo $page_number; ?> / <?php echo $total_pages; ?> 页，每页 <?php echo $page_size; ?> 篇</p>
            <?php if ($page_number > 1): ?>
                <a href="?page=<?php echo $page_number - 1; ?>">上一页</a>
            <?php endif; ?>
            <?php if ($page_number < $total_pages): ?>
                <a href="?page=<?php echo $page_number + 1; ?>">下一页</a>
            <?php endif; ?>
            <form method="get">
                <label for="page">跳转页码</label>
                <input id="page" name="page" type="number" min="1" max="<?php echo $total_pages; ?>" value="<?php echo $page_number; ?>" required>
                <button type="submit">跳转</button>
            </form>
        </nav>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>标题</th>
                    <th>语言</th>
                    <th>内容源链接</th>
                    <th>采集时间</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($articles as $art): ?>
                <tr>
                    <td><?php echo $art['id']; ?></td>
                    <td><?php echo htmlspecialchars($art['title']); ?></td>
                    <td><span style="background:#eee;padding:2px 8px;border-radius:10px;font-size:0.9em;"><?php echo htmlspecialchars($art['language']); ?></span></td>
                    <td><a href="<?php echo htmlspecialchars($art['source_url']); ?>" target="_blank" style="color: #3498db;">🔗 原文链接</a></td>
                    <td><?php echo $art['created_at']; ?></td>
                </tr>
                <?php endforeach; ?>
                
                <?php if(empty($articles)): ?>
                <tr>
                    <td colspan="5" style="text-align: center; padding: 30px; color: #777;">
                        暂无文章数据。请先在服务器上运行 <code>python3 spider/spider.py</code> 脚本采集数据。
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>

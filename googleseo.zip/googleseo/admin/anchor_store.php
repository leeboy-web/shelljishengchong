<?php
declare(strict_types=1);

// Fixed assignments and immutable exports share the existing SQLite backup.
function anchorSchema(PDO $db): void {
    $db->exec('CREATE TABLE IF NOT EXISTS anchor_batches (
        id TEXT PRIMARY KEY, request_token TEXT NOT NULL UNIQUE,
        requested INTEGER NOT NULL, anchor_text TEXT NOT NULL,
        target_url TEXT NOT NULL, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS article_anchors (
        article_id INTEGER PRIMARY KEY, source_url TEXT NOT NULL,
        language TEXT NOT NULL, batch_id TEXT NOT NULL,
        filename TEXT NOT NULL, status TEXT NOT NULL DEFAULT "pending",
        error TEXT NOT NULL DEFAULT "", published_url TEXT,
        export_id TEXT, UNIQUE(source_url, language)
    );
    CREATE INDEX IF NOT EXISTS anchor_batch_idx ON article_anchors(batch_id);
    CREATE TABLE IF NOT EXISTS anchor_exports (
        id TEXT PRIMARY KEY, batch_id TEXT NOT NULL,
        filename TEXT NOT NULL UNIQUE, payload TEXT NOT NULL,
        created_at TEXT NOT NULL
    )');
}

function anchorEscape(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function anchorValidate(string $text, string $url, int $count): void {
    if ($count < 1 || $count > 100000) {
        throw new InvalidArgumentException('Article count must be between 1 and 100000.');
    }
    if (trim($text) === '' || strlen($text) > 1000 || preg_match('/[\x00-\x1f\x7f]/', $text)) {
        throw new InvalidArgumentException('Anchor text is empty, too long or contains control characters.');
    }
    $parts = parse_url($url);
    if (strlen($url) > 2048 || filter_var($url, FILTER_VALIDATE_URL) === false ||
        !$parts || !in_array(strtolower($parts['scheme'] ?? ''), ['http', 'https'], true) ||
        empty($parts['host']) || isset($parts['user']) || isset($parts['pass']) ||
        preg_match('/[\x00-\x20\x7f]/', $url)) {
        throw new InvalidArgumentException('Target must be a valid HTTP or HTTPS URL without credentials.');
    }
}

function anchorBatch(PDO $db, string $id): array {
    $query = $db->prepare('SELECT * FROM anchor_batches WHERE id = ?');
    $query->execute([$id]);
    $batch = $query->fetch(PDO::FETCH_ASSOC);
    if (!$batch) {
        throw new RuntimeException('Unknown anchor batch.');
    }
    return $batch;
}

function anchorCreateBatch(PDO $db, string $token, string $text, string $url, int $count, string $output): string {
    anchorValidate($text, $url, $count);
    if (!preg_match('/^[a-f0-9]{64}$/D', $token)) {
        throw new InvalidArgumentException('Invalid request token.');
    }
    $db->beginTransaction();
    try {
        $query = $db->prepare('SELECT id FROM anchor_batches WHERE request_token = ?');
        $query->execute([$token]);
        $existing = $query->fetchColumn();
        if ($existing !== false) {
            $db->commit();
            return $existing;
        }
        // Random across all languages/categories, excluding every prior assignment.
        $candidates = $db->query('SELECT a.id, a.source_url, a.language, u.filename
            FROM articles a JOIN article_url_bindings u ON u.article_id = a.id
                AND u.source_url = a.source_url AND u.language = a.language
            WHERE NOT EXISTS (SELECT 1 FROM article_anchors x
                WHERE x.article_id = a.id OR (x.source_url = a.source_url AND x.language = a.language))
            ORDER BY RANDOM()');
        $selected = [];
        while ($row = $candidates->fetch(PDO::FETCH_ASSOC)) {
            if (preg_match('/^[a-z0-9-]+-[0-9]+\.html$/D', $row['filename']) &&
                is_file(rtrim($output, '/\\') . '/' . $row['filename'])) {
                $selected[] = $row;
                if (count($selected) === $count) {
                    break;
                }
            }
        }
        $candidates->closeCursor();
        if (!$selected) {
            throw new RuntimeException('No unassigned published articles. Generate pages first or collect new articles.');
        }
        $id = gmdate('Ymd_His') . '_' . bin2hex(random_bytes(8));
        $insert = $db->prepare('INSERT INTO anchor_batches VALUES (?, ?, ?, ?, ?, ?)');
        $insert->execute([$id, $token, $count, $text, $url, gmdate('c')]);
        $insert = $db->prepare('INSERT INTO article_anchors
            (article_id, source_url, language, batch_id, filename) VALUES (?, ?, ?, ?, ?)');
        foreach ($selected as $row) {
            $insert->execute([$row['id'], $row['source_url'], $row['language'], $id, $row['filename']]);
        }
        $db->commit();
        return $id;
    } catch (Throwable $error) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        throw $error;
    }
}

function anchorAssignments(PDO $db): array {
    $rows = $db->query('SELECT x.*, b.anchor_text, b.target_url
        FROM article_anchors x JOIN anchor_batches b ON b.id = x.batch_id')->fetchAll(PDO::FETCH_ASSOC);
    $result = [];
    foreach ($rows as $row) {
        $result[(int)$row['article_id']] = $row;
    }
    return $result;
}

function anchorAssertIdentity(array $assignment, array $article, string $filename): void {
    if ($assignment['source_url'] !== $article['source_url'] ||
        $assignment['language'] !== $article['language'] || $assignment['filename'] !== $filename) {
        throw new RuntimeException('Anchor identity mismatch for article ' . $article['id'] . '. Restore bindings before generating.');
    }
}

function anchorMarkup(array $assignment): string {
    return '<p class="external-anchor" data-anchor-batch="' . anchorEscape($assignment['batch_id']) .
        '"><a href="' . anchorEscape($assignment['target_url']) . '">' .
        anchorEscape($assignment['anchor_text']) . '</a></p>';
}

function anchorVerify(string $html, array $assignment): void {
    $document = new DOMDocument();
    $previous = libxml_use_internal_errors(true);
    try {
        $document->loadHTML('<?xml encoding="UTF-8">' . $html);
        $xpath = new DOMXPath($document);
        $nodes = $xpath->query('//*[@data-anchor-batch]');
        if ($nodes->length !== 1 || $nodes->item(0)->getAttribute('data-anchor-batch') !== $assignment['batch_id']) {
            throw new RuntimeException('Expected exactly one anchor block. Check article_content in the template.');
        }
        $links = $nodes->item(0)->getElementsByTagName('a');
        if ($links->length !== 1 || $links->item(0)->getAttribute('href') !== $assignment['target_url'] ||
            $links->item(0)->textContent !== $assignment['anchor_text']) {
            throw new RuntimeException('Rendered anchor text or destination does not match the assignment.');
        }
    } finally {
        libxml_clear_errors();
        libxml_use_internal_errors($previous);
    }
}

function anchorPublished(PDO $db, int $id, string $url): void {
    $query = $db->prepare('UPDATE article_anchors SET status = "success", error = "", published_url = ? WHERE article_id = ?');
    $query->execute([$url, $id]);
}

function anchorFailed(PDO $db, int $id, string $message): void {
    $query = $db->prepare('UPDATE article_anchors SET status = "failed", error = ? WHERE article_id = ?');
    $query->execute([substr($message, 0, 2000), $id]);
}

function anchorEnsureExportFile(array $export, string $directory): string {
    if (!preg_match('/^batch_[a-zA-Z0-9_]+\.txt$/D', $export['filename'])) {
        throw new RuntimeException('Invalid export filename.');
    }
    if (!is_dir($directory) && !mkdir($directory, 0700, true) && !is_dir($directory)) {
        throw new RuntimeException('Cannot create anchor export directory.');
    }
    $path = rtrim($directory, '/\\') . '/' . $export['filename'];
    if (is_file($path)) {
        if (file_get_contents($path) !== $export['payload']) {
            throw new RuntimeException('Existing export differs from its saved snapshot; it was not overwritten.');
        }
        return $path;
    }
    $handle = fopen($path, 'xb');
    if ($handle === false) {
        throw new RuntimeException('Cannot create new export file.');
    }
    $complete = false;
    try {
        $payload = $export['payload'];
        $offset = 0;
        while ($offset < strlen($payload)) {
            $written = fwrite($handle, substr($payload, $offset));
            if ($written === false || $written === 0) {
                throw new RuntimeException('Cannot finish export file.');
            }
            $offset += $written;
        }
        if (!fflush($handle)) {
            throw new RuntimeException('Cannot flush export file.');
        }
        $complete = true;
    } finally {
        fclose($handle);
        if (!$complete) {
            unlink($path); // Only remove the incomplete file created by this call.
        }
    }
    return $path;
}

function anchorExportReady(PDO $db, string $output, string $directory): array {
    $query = $db->query('SELECT x.*, b.anchor_text, b.target_url FROM article_anchors x
        JOIN anchor_batches b ON b.id = x.batch_id
        WHERE x.status = "success" AND x.export_id IS NULL ORDER BY x.batch_id, x.article_id');
    $groups = [];
    foreach ($query->fetchAll(PDO::FETCH_ASSOC) as $row) {
        try {
            $path = rtrim($output, '/\\') . '/' . $row['filename'];
            if (!is_file($path)) {
                throw new RuntimeException('Published page is missing.');
            }
            $html = file_get_contents($path);
            if ($html === false) {
                throw new RuntimeException('Cannot read published page.');
            }
            anchorVerify($html, $row);
            $groups[$row['batch_id']][] = $row;
        } catch (Throwable $error) {
            anchorFailed($db, (int)$row['article_id'], $error->getMessage());
        }
    }
    foreach ($groups as $batchId => $rows) {
        $id = bin2hex(random_bytes(16));
        $filename = 'batch_' . $batchId . '_' . $id . '.txt';
        $payload = implode("\n", array_column($rows, 'published_url')) . "\n";
        // Snapshot and assignment flags commit together; disk repair never reassigns articles.
        $db->beginTransaction();
        try {
            $insert = $db->prepare('INSERT INTO anchor_exports VALUES (?, ?, ?, ?, ?)');
            $insert->execute([$id, $batchId, $filename, $payload, gmdate('c')]);
            $update = $db->prepare('UPDATE article_anchors SET export_id = ? WHERE article_id = ? AND export_id IS NULL');
            foreach ($rows as $row) {
                $update->execute([$id, $row['article_id']]);
                if ($update->rowCount() !== 1) {
                    throw new RuntimeException('Concurrent anchor export detected.');
                }
            }
            $db->commit();
        } catch (Throwable $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $error;
        }
    }
    $exports = $db->query('SELECT * FROM anchor_exports ORDER BY created_at, id')->fetchAll(PDO::FETCH_ASSOC);
    foreach ($exports as $export) {
        anchorEnsureExportFile($export, $directory);
    }
    return $exports;
}

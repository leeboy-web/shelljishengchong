<?php
// config.php - 全局配置文件

// 定义系统绝对路径
define('BASE_DIR', dirname(__DIR__));
define('DB_PATH', BASE_DIR . '/data/seo_data.db');
define('OUTPUT_DIR', BASE_DIR . '/public/');
define('SITE_URL', 'http://facegfx.com/yuenan/googleseo/public'); // 修改为你的实际域名

// ================= TDK 规则配置 =================
// 魔法变量说明：
// {title} : 采集到的文章原本标题 (如果你想用采集的真实标题，用这个)
// {keyword} : 从关键词库 (data/keywords_pt.txt) 中随机抽取的一行
// {custom_title} : 从标题库 (data/titles_pt.txt) 中随机抽取的一行
// {custom_desc} : 从描述库 (data/descriptions_pt.txt) 中随机抽取的一行
$seo_config = [
    // 越南市场配置 (当前正在使用的)
    'vi' => [
        // 新闻标题与相关推荐一致；关键词和描述仍使用各自的 TXT 库。
        'title_rule' => '{article_title}',
        'keywords'   => '{keyword}',
        'desc_rule'  => '{custom_desc}'
    ],
    // 葡萄牙市场配置
    'pt' => [
        // 如果你想完全使用自己准备的标题库，就把 title_rule 写成 '{custom_title}'
        'title_rule' => '{custom_title}', 
        'keywords'   => '{keyword}',
        // 如果你想完全使用自己准备的描述库，就把 desc_rule 写成 '{custom_desc}'
        'desc_rule'  => '{custom_desc}'
    ],
    // 如果后续你要做英文市场，只需复制并修改为 'en'
    'en' => [
        'title_rule' => '{custom_title}',
        'keywords'   => '{keyword}',
        'desc_rule'  => '{custom_desc}'
    ]
];
?>

<?php
// Set a private password of at least 12 characters before using anchors.php.
// Do not overwrite this server file after configuring it.
return '';

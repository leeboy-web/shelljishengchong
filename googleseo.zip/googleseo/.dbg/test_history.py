import sys
import sqlite3
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).parent / "test-deps"))
sys.path.insert(0, str(Path(__file__).parents[1] / "spider"))
import spider

db = sqlite3.connect(":memory:")
spider.init_queue(db)
source = dict(spider.default_source(), name="test", allowed_hosts=["source.test"],
              list_page_template="https://source.test/page/{page}/", list_pages_per_run=2,
              sitemap_urls=["https://source.test/sitemap.xml"], sitemap_files_per_run=2)

class Response:
    url = "https://source.test/sitemap.xml"
    content = b'<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><sitemap><loc>https://source.test/leaf.xml</loc></sitemap></sitemapindex>'
    def raise_for_status(self):
        pass

def get(url, **kwargs):
    r = Response()
    r.url = url
    if url.endswith("leaf.xml"):
        r.content = b'<urlset><url><loc>https://source.test/news.html</loc></url><url><loc>https://foreign.test/news.html</loc></url></urlset>'
    return r

pages = []
def listing(s):
    pages.append(s["list_url"])
    return [f"https://source.test/page-{len(pages)}.html"]

with patch.object(spider.requests, "get", side_effect=get), \
     patch.object(spider, "fetch_article_list", side_effect=listing), \
     patch.object(spider.time, "sleep"):
    spider.discover_history(db, source)
    spider.discover_history(db, source)
assert pages == [f"https://source.test/page/{i}/" for i in range(2, 6)]
assert db.execute("SELECT COUNT(*) FROM crawl_queue").fetchone()[0] == 5
assert db.execute("SELECT COUNT(*) FROM crawl_sitemaps").fetchone()[0] == 2
print("PASS: archive continuation, sitemap index traversal, queue deduplication, host restriction")
db.close()

if "--live" in sys.argv:
    db = sqlite3.connect(":memory:")
    spider.init_queue(db)
    for s in spider.load_sources():
        s = dict(s, list_pages_per_run=1, sitemap_files_per_run=5)
        spider.discover_history(db, s)
        count = db.execute("SELECT COUNT(*) FROM crawl_queue WHERE source=?", (s["name"],)).fetchone()[0]
        print("LIVE DISCOVERED", s["name"], count)
        assert count > 0, s["name"]
    db.close()

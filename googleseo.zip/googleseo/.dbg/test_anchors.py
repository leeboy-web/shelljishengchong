"""Run isolated PHP/SQLite integration and HTTP tests; never use the live database."""
import hashlib
import http.cookiejar
import json
import re
import shutil
import socket
import sqlite3
import subprocess
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from contextlib import contextmanager
from pathlib import Path

root = Path(__file__).resolve().parents[1]
php = root / ".dbg/php/php.exe"
command = [str(php), "-n", "-d", f'extension_dir="{php.parent / "ext"}"',
           "-d", "extension=mbstring", "-d", "extension=pdo_sqlite"]

@contextmanager
def database(path):
    connection = sqlite3.connect(path)
    try:
        with connection:
            yield connection
    finally:
        connection.close()

with tempfile.TemporaryDirectory() as temporary:
    base = Path(temporary)
    (base / "admin/templates").mkdir(parents=True)
    (base / "data").mkdir()
    for name in ["generate.php", "anchor_store.php", "anchors.php", "anchor_access.php"]:
        shutil.copy(root / "admin" / name, base / "admin" / name)
    (base / "admin/config.php").write_text(
        "<?php define('BASE_DIR',dirname(__DIR__));define('OUTPUT_DIR',BASE_DIR.'/public');"
        "define('DB_PATH',BASE_DIR.'/data/seo_data.db');"
        "define('SITE_URL','http://example.test/news');$seo_config=[];", encoding="utf-8")
    template = ("<html><head><style>body{color:black}</style><title>{seo_title}</title></head>"
                "<body><h1>{article_title}</h1>{article_content}</body></html>")
    (base / "admin/templates/vi_test.html").write_text(template, encoding="utf-8")
    (base / "admin/anchor_access.php").write_text("<?php return 'test-private-password';", encoding="utf-8")
    db_path = base / "data/seo_data.db"
    with database(db_path) as db:
        db.execute("CREATE TABLE articles(id INTEGER PRIMARY KEY,title TEXT,content TEXT,"
                   "language TEXT,source_url TEXT)")
        for i in range(1, 9):
            db.execute("INSERT INTO articles VALUES (?,?,?,?,?)",
                       (i, f"News {i}", f"<p>Body {i}</p>", "vi", f"https://source.test/{i}"))
    (base / "data/keywords_vi.txt").write_text("first\nsecond\n", encoding="utf-8")

    def evaluate(code):
        result = subprocess.run(command + ["-r", code], capture_output=True)
        output = result.stdout + result.stderr
        assert result.returncode == 0 and b"Warning" not in output, output.decode(errors="replace")
        return result.stdout.decode("utf-8")

    prefix = (f"require '{(base / 'admin/config.php').as_posix()}';"
              f"require '{(base / 'admin/anchor_store.php').as_posix()}';"
              "$db=new PDO('sqlite:'.DB_PATH,null,null,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);"
              "anchorSchema($db);")

    def generate(batch=None):
        setup = f"$anchor_only_batch_id='{batch}';" if batch else ""
        return evaluate(setup + f"require '{(base / 'admin/generate.php').as_posix()}';")

    def rows(sql):
        with database(db_path) as db:
            db.row_factory = sqlite3.Row
            return [dict(row) for row in db.execute(sql)]

    def create(token, count, text="Custom {keyword} & news", url="https://outside.test/guide?a=1&b=2"):
        return evaluate(prefix + "echo anchorCreateBatch($db," +
                        ",".join(json.dumps(value) for value in [token, text, url, count]) +
                        ",OUTPUT_DIR);")

    generate()
    home = (base / "public/index.html").read_bytes()
    original_urls = rows("SELECT * FROM article_url_bindings ORDER BY article_id")
    batch1 = create("a" * 64, 3)
    assert create("a" * 64, 3) == batch1
    assert len(rows("SELECT * FROM anchor_batches")) == 1
    untouched = {p.name: p.read_bytes() for p in (base / "public").glob("*.html")}
    first = rows("SELECT * FROM article_anchors")
    assert len(first) == 3
    generate(batch1)
    assert all(row["status"] == "success" for row in rows("SELECT * FROM article_anchors"))
    for assignment in first:
        html = (base / "public" / assignment["filename"]).read_text(encoding="utf-8")
        assert html.count('data-anchor-batch=') == 1
        assert "Custom {keyword} &amp; news" in html
        assert html.index("external-anchor") < html.index('class="related-posts"')
    selected = {row["filename"] for row in first}
    for name, content in untouched.items():
        if name not in selected:
            assert (base / "public" / name).read_bytes() == content
    exports = list((base / "data/anchor_exports").glob("*.txt"))
    assert len(exports) == 1
    expected = {"http://example.test/news/" + row["filename"] for row in first}
    assert set(exports[0].read_text().splitlines()) == expected
    old_exports = {p.name: p.read_bytes() for p in exports}
    generate(batch1)
    assert len(list((base / "data/anchor_exports").glob("*.txt"))) == 1

    # A missing bound template fails one article; success exports remain immutable.
    batch2 = create("b" * 64, 2, "Second link", "https://outside.test/second")
    second = rows(f"SELECT * FROM article_anchors WHERE batch_id='{batch2}'")
    assert not selected.intersection(row["filename"] for row in second)
    bindings_path = base / "data/template_bindings.json"
    bindings = json.loads(bindings_path.read_text(encoding="utf-8"))
    failed_id = str(second[0]["article_id"])
    bindings[failed_id]["template"] = "vi_missing.html"
    bindings_path.write_text(json.dumps(bindings), encoding="utf-8")
    generate(batch2)
    assert len(rows('SELECT * FROM article_anchors WHERE status="failed"')) == 1
    assert len(list((base / "data/anchor_exports").glob("*.txt"))) == 2
    before_retry = {p.name: p.read_bytes() for p in (base / "data/anchor_exports").glob("*.txt")}
    bindings[failed_id]["template"] = "vi_test.html"
    bindings_path.write_text(json.dumps(bindings), encoding="utf-8")
    generate(batch2)
    assert not rows('SELECT * FROM article_anchors WHERE status!="success"')
    assert len(list((base / "data/anchor_exports").glob("*.txt"))) == 3
    for name, content in before_retry.items():
        assert (base / "data/anchor_exports" / name).read_bytes() == content
    (base / "data/keywords_vi.txt").write_text("new\nchanged\nmore\n", encoding="utf-8")
    generate()
    assert rows("SELECT * FROM article_url_bindings ORDER BY article_id") == original_urls
    assert (base / "public/index.html").read_bytes() == home
    for row in rows("SELECT * FROM article_anchors"):
        assert (base / "public" / row["filename"]).read_text(encoding="utf-8").count('data-anchor-batch=') == 1
    assert len(list((base / "data/anchor_exports").glob("*.txt"))) == 3
    sitemap = ET.parse(base / "public/sitemap.xml")
    assert len([n for n in sitemap.iter() if n.tag.endswith("loc")]) == 9
    batch3 = create("c" * 64, 100)
    assert len(rows(f"SELECT * FROM article_anchors WHERE batch_id='{batch3}'")) == 3
    generate(batch3)
    assert len(rows("SELECT * FROM article_anchors")) == 8
    assert len(rows("SELECT * FROM anchor_exports")) == 4
    first_export = rows("SELECT * FROM anchor_exports ORDER BY created_at,id")[0]
    export_path = base / "data/anchor_exports" / first_export["filename"]
    original_payload = export_path.read_bytes()
    export_path.unlink()
    evaluate(prefix + "anchorExportReady($db,OUTPUT_DIR,BASE_DIR.'/data/anchor_exports');")
    assert export_path.read_bytes() == original_payload
    export_path.write_text("Do not overwrite", encoding="utf-8")
    result = evaluate(prefix + "try{anchorExportReady($db,OUTPUT_DIR,BASE_DIR.'/data/anchor_exports');}"
                      "catch(Throwable $e){echo $e->getMessage();}")
    assert "not overwritten" in result and export_path.read_text() == "Do not overwrite"
    export_path.write_bytes(original_payload)
    for url in ["javascript:alert(1)", "https://user:pass@outside.test/", "ftp://outside.test/"]:
        result = evaluate(prefix + f"try{{anchorValidate('text',{json.dumps(url)},1);echo 'BAD';}}"
                          "catch(Throwable $e){echo 'rejected';}")
        assert result == "rejected"

    # Exercise the real controller, authentication, CSRF and download authorization.
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    server = subprocess.Popen(command + ["-S", f"127.0.0.1:{port}", "-t", str(base)],
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        url = f"http://127.0.0.1:{port}/admin/anchors.php"
        opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        for attempt in range(30):
            try:
                login = opener.open(url, timeout=2).read().decode()
                break
            except urllib.error.URLError:
                if server.poll() is not None:
                    raise
                time.sleep(0.1)
        assert "password" in login
        csrf = re.search(r'name="csrf" value="([^"]+)"', login).group(1)
        request = urllib.parse.urlencode({"csrf": csrf, "action": "login", "password": "test-private-password"}).encode()
        page = opener.open(url, request).read().decode()
        assert "name=\"count\"" in page
        for download in rows("SELECT * FROM anchor_exports"):
            body = opener.open(url + "?download=" + download["id"]).read().decode()
            assert body == download["payload"]
        try:
            opener.open(url, urllib.parse.urlencode({"action": "create", "csrf": "bad"}).encode())
            raise AssertionError("CSRF bypass")
        except urllib.error.HTTPError as error:
            assert error.code == 403
        csrf = re.search(r'name="csrf" value="([^"]+)"', page).group(1)
        request_token = re.search(r'name="request_token" value="([^"]+)"', page).group(1)
        with database(db_path) as db:
            db.execute("INSERT INTO articles VALUES(9,'News 9','<p>Body 9</p>','vi','https://source.test/9')")
        generate()
        request = urllib.parse.urlencode({"csrf": csrf, "action": "create", "request_token": request_token,
                                        "count": "1", "anchor_text": "HTTP link",
                                        "target_url": "https://outside.test/http", "confirm": "yes"}).encode()
        response = opener.open(url, request).read().decode()
        assert "Warning" not in response
        count = len(rows("SELECT * FROM anchor_batches"))
        opener.open(url, request).read()
        assert len(rows("SELECT * FROM anchor_batches")) == count == 4
        anonymous = urllib.request.urlopen(url + "?download=" + first_export["id"]).read().decode()
        assert 'type="password"' in anonymous and "http://example.test/news/" not in anonymous
        opener.open(url + "?new_form=1").read()
    finally:
        server.terminate()
        server.wait(timeout=5)

print("PASS: random disjoint batches, idempotent submit, shortage, fixed anchors/URLs/homepage,")
print("partial failure + supplementary TXT, immutable exports + recovery, sitemap, URL validation,")
print("real HTTP login, CSRF, authenticated downloads and controller generation.")

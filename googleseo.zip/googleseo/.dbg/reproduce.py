import json
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import re
import html
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
php = Path(sys.argv[1]).resolve()
with tempfile.TemporaryDirectory(prefix="news-mapping-") as temporary:
    base = Path(temporary)
    (base / "admin" / "templates").mkdir(parents=True)
    (base / "data").mkdir()
    shutil.copy(root / "admin" / "generate.php", base / "admin" / "generate.php")
    (base / "admin" / "config.php").write_text(
        "<?php define('BASE_DIR', dirname(__DIR__));"
        "define('DB_PATH', BASE_DIR.'/data/seo_data.db');"
        "define('OUTPUT_DIR', BASE_DIR.'/public');"
        "define('SITE_URL', 'http://example.test/public');"
        "$seo_config=['vi'=>['title_rule'=>'{article_title}',"
        "'keywords'=>'{keyword}','desc_rule'=>'{custom_desc}'],"
        "'pt'=>['title_rule'=>'{title}','keywords'=>'{keyword}',"
        "'desc_rule'=>'{custom_desc}']];",
        encoding="utf-8",
    )
    (base / "admin" / "templates" / "vi_test.html").write_text(
        "<html><head><title>{seo_title}</title></head>"
        "<body><h1>{article_title}</h1>{article_content}</body></html>",
        encoding="utf-8",
    )
    (base / "data" / "keywords_vi.txt").write_text("plants\nsoil\n", encoding="utf-8")
    (base / "data" / "titles_vi.txt").write_text("Custom unrelated headline\n", encoding="utf-8")
    with sqlite3.connect(base / "data" / "seo_data.db") as connection:
        connection.execute("CREATE TABLE articles (id INTEGER PRIMARY KEY, title TEXT, content TEXT, language TEXT, created_at TEXT, source_url TEXT)")
        connection.executemany(
            "INSERT INTO articles VALUES (?, ?, ?, 'vi', '2026-10-13', ?)",
            [(i, f"Original news {i}",
              f"<p>Article body {i}</p>"
              "<section class='source-cards'>"
              "<a href='/news-2.html' onclick='return false' target='_blank'><h3>Original news 2</h3></a>"
              "<a href='https://source.test/news-2.html#photo'><img src='uploads/photo.jpg' alt='News 2'></a>"
              "<a href='//source.test/news-3.html'><h3>Original news 3</h3></a>"
              "<a href='https://source.test/missing.html'>Not collected</a></section>",
              f"https://source.test/news-{i}.html") for i in range(1, 9)],
        )
    connection.close()
    run_id = sys.argv[2] if len(sys.argv) > 2 else "pre-fix"
    environment = dict(os.environ, NEWS_DEBUG_URL="http://127.0.0.1:7777/event", NEWS_DEBUG_RUN=run_id)
    result = subprocess.run(
        [str(php), "-n", "-d", f'extension_dir="{php.parent / "ext"}"',
         "-d", "extension=mbstring", "-d", "extension=pdo_sqlite",
         str(base / "admin" / "generate.php")],
        cwd=base / "admin", env=environment, capture_output=True, text=True,
    )
    pages = list((base / "public").glob("*.html"))
    checked = 0
    if run_id == "post-fix":
        assert result.returncode == 0 and "Warning" not in result.stdout, result.stdout
        assert len(pages) == 9
        for page in pages:
            content = page.read_text(encoding="utf-8")
            cards = re.search(r'<section class="source-cards">(.*?)</section>', content, re.S).group(1)
            card_links = re.findall(r'<a href="([^"]+)"[^>]*>(.*?)</a>', cards, re.S)
            assert len(card_links) == 3
            assert "onclick" not in cards and "Not collected</a>" not in cards
            for url, label in card_links:
                assert "://" not in url
                target = (base / "public" / url).read_text(encoding="utf-8")
                expected = "Original news 2" if "<img" in label else re.sub("<[^>]+>", "", label)
                assert f"<h1>{expected}</h1>" in target
            title = re.search(r"<h1>(.*?)</h1>", content).group(1)
            assert "Original news" in title and "Custom unrelated" not in title
            related = re.search(r'<div class="related-posts".*?</div>', content, re.S).group()
            links = re.findall(r'<a href="([^"]+)"[^>]*>(.*?)</a>', related)
            assert len(links) >= 3
            assert len({url for url, _ in links}) == len(links)
            for url, label in links:
                target = (base / "public" / url).read_text(encoding="utf-8")
                assert html.unescape(label) == html.unescape(re.search(r"<h1>(.*?)</h1>", target).group(1))
                number = label.rsplit(" ", 1)[-1]
                assert f"Article body {number}" in target
                checked += 1
        original_xml = ET.parse(base / "public" / "sitemap.xml")
        assert len(original_xml.getroot()) == 9
        (base / "spider").mkdir()
        shutil.copy(root / "spider" / "generate_sitemap.py", base / "spider" / "generate_sitemap.py")
        subprocess.run([sys.executable, "-B", str(base / "spider" / "generate_sitemap.py")], check=True)
        updated_xml = ET.parse(base / "public" / "sitemap.xml")
        assert [e[0].text for e in original_xml.getroot()] == [e[0].text for e in updated_xml.getroot()]
    print(json.dumps({
        "returncode": result.returncode, "input_articles": 8,
        "output_article_files": len([p for p in pages if p.name != "index.html"]),
        "custom_headings": sum("<h1>Custom unrelated headline</h1>" in p.read_text(encoding="utf-8") for p in pages),
        "warnings": result.stdout.count("Warning"),
        "stderr": result.stderr[:300],
        "stdout": result.stdout[:500] if not pages else "",
        "verified_related_links": checked,
    }))

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent / "test-deps"))
import requests
from bs4 import BeautifulSoup
for url in ["https://sfarm.vn/blog/page/2/", "https://nongnghiephuuco.vn/", "https://dantri.com.vn/"]:
    r = requests.get(url, timeout=25)
    s = BeautifulSoup(r.content, "html.parser")
    print(url, r.status_code, r.url)
    print("PAGINATION", [(a.get_text(" ", strip=True), a.get("href")) for a in s.select("a.next, a[rel=next], .pagination a")][:8])
    if "/page/" not in url:
        print("CATEGORIES", [(a.get_text(" ", strip=True), a["href"]) for a in s.select("nav a[href]")][:25])
    robots = requests.get(requests.compat.urljoin(url, "/robots.txt"), timeout=20)
    print("SITEMAPS", [line for line in robots.text.splitlines() if line.lower().startswith("sitemap:")][:6])

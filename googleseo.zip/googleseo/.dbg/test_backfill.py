from pathlib import Path
import sqlite3
import sys
from unittest.mock import patch

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / ".dbg" / "test-deps"))
sys.path.insert(0, str(root / "spider"))
import spider

spider.TARGET_LIST_URL = "https://source.test/"
db = sqlite3.connect(":memory:")
db.execute("CREATE TABLE articles(source_url TEXT UNIQUE, content TEXT, language TEXT)")
db.execute("INSERT INTO articles VALUES (?, ?, 'vi')", (
    "https://source.test/old.html",
    "<h2>Related</h2><a href='/related.html'>Related news</a>"
    "<h2>Other news</h2><a attr-href='/other.html'>Other news</a>"
    "<a href='https://foreign.test/news.html'>Foreign</a>",
))
db.commit()
seen = []

def save(url, conn, source=None):
    seen.append(url)
    content = "<a href='/deep.html'>More</a>" if url.endswith("/related.html") else ""
    conn.execute("INSERT INTO articles VALUES (?, ?, 'vi')", (url, content))
    conn.commit()
    return True

with patch.object(spider, "fetch_article_list", return_value=["https://source.test/old.html"]), \
        patch.object(spider, "scrape_article", side_effect=save), \
        patch.object(spider.time, "sleep"):
    spider.MAX_ARTICLES_PER_RUN = 1
    assert spider.collect_articles(db) == 1
    spider.MAX_ARTICLES_PER_RUN = 100
    assert spider.collect_articles(db) == 2
    assert spider.collect_articles(db) == 0
assert set(seen) == {
    "https://source.test/related.html",
    "https://source.test/other.html",
    "https://source.test/deep.html",
}
db.close()
print("PASS: existing related/other links, nested links, limit/resume, deduplication, host restriction")

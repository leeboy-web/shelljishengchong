from pathlib import Path
import sys
import sqlite3
from unittest.mock import patch

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / ".dbg" / "test-deps"))
sys.path.insert(0, str(root / "spider"))
import spider

sources = spider.load_sources()
db = sqlite3.connect(":memory:")
db.execute("CREATE TABLE articles(id INTEGER PRIMARY KEY, title TEXT, content TEXT, language TEXT, source_url TEXT UNIQUE, created_at TEXT)")
for source in sources:
    links = spider.fetch_article_list(source)
    assert links, source["name"] + ": no article links"
    print(source["name"], "list links:", len(links))
    assert spider.normalize_article_url("https://foreign.test/news.html", source["list_url"], source) is None
    chosen = links[0]
    # Test actual article parsing/insertion while skipping image downloads in this smoke run.
    original_get = spider.requests.get
    def get(url, **kwargs):
        if url == chosen:
            response = original_get(url, **kwargs)
            soup = spider.BeautifulSoup(response.content, "html.parser")
            body = soup.select_one(source["content_selector"])
            assert body and len(body.get_text(strip=True)) > 100, source["name"]
            for img in body.select("img"):
                img.decompose()
            response._content = str(soup).encode("utf-8")
            return response
        raise AssertionError("Unexpected request " + url)
    with patch.object(spider.requests, "get", side_effect=get):
        assert spider.scrape_article(chosen, db, source)
        assert not spider.scrape_article(chosen, db, source)
    row = db.execute("SELECT title, language FROM articles WHERE source_url=?", (chosen,)).fetchone()
    assert row and row[1] == "vi"
    print("PASS", source["name"], "title chars:", len(row[0]))
db.close()

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent / "test-deps"))
import requests
from bs4 import BeautifulSoup

for home in ["https://sfarm.vn/", "https://dantri.com.vn/"]:
    r = requests.get(home, timeout=25)
    print(home, r.status_code)
    soup = BeautifulSoup(r.content, "html.parser")
    links = []
    for a in soup.select("h2 a[href], h3 a[href], .post-title a[href], .entry-title a[href]"):
        url = requests.compat.urljoin(home, a["href"])
        if url.startswith(home) and url != home and url not in links:
            links.append(url)
    print("SAMPLES", links[:4])
    for url in links[:2]:
        r = requests.get(url, timeout=25)
        s = BeautifulSoup(r.content, "html.parser")
        print("DETAIL", url, r.status_code)
        print("H1", [(x.get("class"), x.get_text(" ", strip=True)[:100]) for x in s.select("h1")])
        if "dantri" in home:
            p = next((p for p in s.select("p") if len(p.get_text()) > 150), None)
            if p:
                print("PARAGRAPH ANCESTORS", [(x.name, x.get("class"), x.get("id")) for x in list(p.parents)[:5]])
        if "sfarm" in home:
            print("LIST CLASSES", [(a.parent.name, a.parent.get("class")) for a in s.select('a[href]') if a.get("href", "").startswith(home)][:5])
        for selector in [".entry-content", ".article-content", ".singular-content", ".dt-news__content", ".td-post-content"]:
            el = s.select_one(selector)
            if el:
                print("CONTENT", selector, len(el.get_text()), str(el)[:150])

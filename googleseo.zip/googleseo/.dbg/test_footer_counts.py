from pathlib import Path
import re
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
source = (root / "admin" / "generate.php").read_text(encoding="utf-8")
assignment = re.search(r"\$link_count = rand\(\d+, \d+\);", source).group()
selection = re.search(r"\$candidates = array_values.*?shuffle\(\$candidates\);", source, re.S).group()
sampling = re.search(r"array_slice\(\$candidates, 0, \$link_count\)", source).group()
code = """
foreach ([1, 59, 201, 501, 1201] as $total) {
    $pages = [];
    for ($i = 0; $i < $total; $i++) {
        $pages[] = ['filename' => 'article-' . $i . '.html', 'language' => 'vi'];
    }
    $pages[] = ['filename' => 'foreign.html', 'language' => 'en'];
    $lang = 'vi';
    $current_filename = 'article-0.html';
    for ($run = 0; $run < 50; $run++) {
        ASSIGNMENT
        SELECTION
        $targets = SAMPLING;
        $urls = array_column($targets, 'filename');
        $count = count($urls);
        if ($count !== min($link_count, $total - 1) ||
            $link_count < 200 || $link_count > 1000 ||
            count(array_unique($urls)) !== $count ||
            in_array($current_filename, $urls) || in_array('foreign.html', $urls)) {
            throw new Exception('Footer count/identity test failed');
        }
    }
}
echo 'PASS: 250 footer samples; 200-1000 limit, insufficient articles, unique URLs, no self/foreign links';
""".replace("ASSIGNMENT", assignment).replace("SELECTION", selection).replace("SAMPLING", sampling)
subprocess.run([sys.argv[1], "-n", "-r", code], check=True)

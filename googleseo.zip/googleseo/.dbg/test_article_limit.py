"""Offline tests of the shared cap; never use the live database."""
import sqlite3
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / ".dbg/test-deps"))
sys.path.insert(0, str(root / "spider"))
import spider

with tempfile.TemporaryDirectory() as temporary:
    base = Path(temporary)
    limits = base / "limits.json"
    limits.write_text('{"max_total_articles":5000}', encoding="utf-8")
    connection = sqlite3.connect(base / "cap.db")
    try:
        connection.execute("CREATE TABLE articles(id INTEGER PRIMARY KEY,title TEXT,content TEXT,"
                           "language TEXT,source_url TEXT UNIQUE,created_at TEXT)")
        connection.executemany("INSERT INTO articles(id,source_url,language) VALUES(?,?,?)",
                               ((i, f"https://old{i % 3}.test/{i}", "vi" if i % 2 else "en")
                                for i in range(1, 5000)))
        connection.commit()
        sources = [dict(spider.default_source(), name=f"source{i}", allowed_hosts=[f"source{i}.test"])
                   for i in range(1, 5)]
        response = type("Response", (), {
            "url": "https://source1.test/new.html",
            "content": b'<h1 class="article-detail-title">News</h1><div class="nnhc-detail-content"><p>Body</p></div>',
            "raise_for_status": lambda self: None})()
        with patch.object(spider, "LIMITS_PATH", str(limits)), patch.object(
                spider.requests, "get", return_value=response) as request:
            assert spider.scrape_article(response.url, connection, sources[0])
            assert connection.execute("SELECT COUNT(*) FROM articles").fetchone()[0] == 5000
            for source in sources:
                assert not spider.scrape_article(f"https://{source['allowed_hosts'][0]}/another.html",
                                                connection, source)
                assert spider.collect_articles(connection, source) == 0
            assert request.call_count == 1
            connection.execute("DELETE FROM articles WHERE source_url=?", (response.url,))
            connection.commit()

            def concurrent_insert(*args, **kwargs):
                other = sqlite3.connect(base / "cap.db")
                try:
                    other.execute("INSERT INTO articles(source_url) VALUES('https://other.test/news')")
                    other.commit()
                finally:
                    other.close()
                return response

            request.side_effect = concurrent_insert
            assert not spider.scrape_article(response.url, connection, sources[0])
            assert connection.execute("SELECT COUNT(*) FROM articles").fetchone()[0] == 5000
            request.side_effect = None
            connection.execute("INSERT INTO articles(source_url) VALUES('https://legacy.test/extra')")
            connection.commit()
            assert spider.collect_articles(connection, sources[0]) == 0
            assert connection.execute("SELECT COUNT(*) FROM articles").fetchone()[0] == 5001
        with patch.object(spider, "LIMITS_PATH", str(base / "missing.json")):
            assert spider.article_limit() == 5000
        limits.write_text('{"max_total_articles":0}', encoding="utf-8")
        with patch.object(spider, "LIMITS_PATH", str(limits)):
            try:
                spider.article_limit()
                raise AssertionError("Invalid limit accepted")
            except ValueError:
                pass
    finally:
        connection.close()

print("PASS: all sources/languages share 5000 cap, no requests when full,")
print("concurrent-insert guard, existing excess preserved, default and invalid configuration")

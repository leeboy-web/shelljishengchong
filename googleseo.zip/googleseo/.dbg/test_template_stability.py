import json
import shutil
import sqlite3
import subprocess
import tempfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
php = root / ".dbg/php/php.exe"
with tempfile.TemporaryDirectory() as temp:
    base = Path(temp)
    templates = base / "admin/templates"
    templates.mkdir(parents=True)
    (base / "data").mkdir()
    shutil.copy(root / "admin/generate.php", base / "admin/generate.php")
    shutil.copy(root / "admin/anchor_store.php", base / "admin/anchor_store.php")
    (base / "admin/config.php").write_text(
        "<?php define('BASE_DIR', dirname(__DIR__));define('OUTPUT_DIR',BASE_DIR.'/public');"
        "define('DB_PATH',BASE_DIR.'/data/seo_data.db');define('SITE_URL','http://example.test');"
        "$seo_config=[];", encoding="utf-8")
    for name, color in [("a", "red"), ("b", "blue")]:
        (templates / f"vi_{name}.html").write_text(
            f"<html><head><style>body{{color:{color}}}</style><title>{{seo_title}}</title></head>"
            "<body><h1>{article_title}</h1>{article_content}</body></html>", encoding="utf-8")
    db = sqlite3.connect(base / "data/seo_data.db")
    db.execute("CREATE TABLE articles(id INTEGER PRIMARY KEY,title TEXT,content TEXT,language TEXT,source_url TEXT)")
    for i in range(1, 5):
        db.execute("INSERT INTO articles VALUES (?,?,?,?,?)", (i, f"News {i}", "<p>Body</p>", "vi", f"https://source.test/{i}"))
    db.commit()
    db.close()
    def run():
        result = subprocess.run([str(php), "-n", "-d", f'extension_dir="{php.parent / "ext"}"',
                                 "-d", "extension=mbstring", "-d", "extension=pdo_sqlite",
                                 str(base / "admin/generate.php")], capture_output=True)
        assert result.returncode == 0 and b"Warning" not in result.stdout and b"[success]" not in result.stderr, result.stdout + result.stderr
        assert (base / "data/template_bindings.json").exists(), result.stdout + result.stderr
    run()
    bindings = base / "data/template_bindings.json"
    first = json.loads(bindings.read_text())
    home = (base / "public/index.html").read_bytes()
    # Recover bindings from already generated pages as on an existing deployment.
    bindings.unlink()
    run()
    assert json.loads(bindings.read_text()) == first
    db = sqlite3.connect(base / "data/seo_data.db")
    db.execute("INSERT INTO articles VALUES (5,'New article','<p>New body</p>','vi','https://source.test/5')")
    db.commit()
    db.close()
    (templates / "vi_new.html").write_text("<style>body{color:green}</style><h1>{article_title}</h1>", encoding="utf-8")
    run()
    second = json.loads(bindings.read_text())
    assert all(second[key] == value for key, value in first.items())
    assert (base / "public/index.html").read_bytes() == home
    assert len(second) == 5
print("PASS: existing template recovery, persistent bindings, new templates/articles, unchanged homepage")

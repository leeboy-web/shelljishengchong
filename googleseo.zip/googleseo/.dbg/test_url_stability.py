import json
import shutil
import sqlite3
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from contextlib import contextmanager
from pathlib import Path


root = Path(__file__).resolve().parents[1]
php = root / ".dbg/php/php.exe"

@contextmanager
def database(path):
    connection = sqlite3.connect(path)
    try:
        with connection:
            yield connection
    finally:
        connection.close()

with tempfile.TemporaryDirectory() as temp:
    base = Path(temp)
    (base / "admin/templates").mkdir(parents=True)
    (base / "data").mkdir()
    shutil.copy(root / "admin/generate.php", base / "admin/generate.php")
    shutil.copy(root / "admin/anchor_store.php", base / "admin/anchor_store.php")
    (base / "admin/config.php").write_text(
        "<?php define('BASE_DIR',dirname(__DIR__));"
        "define('OUTPUT_DIR',BASE_DIR.'/public');"
        "define('DB_PATH',BASE_DIR.'/data/seo_data.db');"
        "define('SITE_URL','http://example.test/news');$seo_config=[];",
        encoding="utf-8",
    )
    (base / "admin/templates/vi_test.html").write_text(
        "<html><head><style>body{color:black}</style><title>{seo_title}</title></head>"
        "<body><h1>{article_title}</h1>{article_content}</body></html>",
        encoding="utf-8",
    )
    db_path = base / "data/seo_data.db"
    with database(db_path) as db:
        db.execute("CREATE TABLE articles(id INTEGER PRIMARY KEY,title TEXT,content TEXT,"
                   "language TEXT,source_url TEXT)")
        for i in range(1, 9):
            db.execute("INSERT INTO articles VALUES (?,?,?,?,?)", (
                i, f"News {i}", f'<p>Body {i}</p><a href="https://source.test/{i % 8 + 1}">'
                "Another story</a>", "vi", f"https://source.test/{i}",
            ))
    keywords = base / "data/keywords_vi.txt"
    keywords.write_text("first\nsecond\n", encoding="utf-8")

    def run(success=True):
        result = subprocess.run([
            str(php), "-n", "-d", f'extension_dir="{php.parent / "ext"}"',
            "-d", "extension=mbstring", "-d", "extension=pdo_sqlite",
            str(base / "admin/generate.php"),
        ], capture_output=True)
        output = result.stdout + result.stderr
        if success:
            assert result.returncode == 0 and b"Warning" not in output, output
        else:
            assert result.returncode != 0, output
        return output

    def mapping():
        manifest = json.loads((base / "data/generated_pages.json").read_text(encoding="utf-8"))
        return {entry["article_id"]: entry["filename"] for entry in manifest["pages"]}

    def check_links():
        names = set(mapping().values()) | {"index.html"}
        tree = ET.parse(base / "public/sitemap.xml")
        urls = [element.text for element in tree.iter() if element.tag.endswith("loc")]
        assert {url.rsplit("/", 1)[-1] for url in urls} == names
        for name in names:
            assert (base / "public" / name).is_file()
        for id_, name in mapping().items():
            html = (base / "public" / name).read_text(encoding="utf-8")
            assert f"<h1>News {id_}</h1>" in html
            for other_name in mapping().values():
                if other_name != name:
                    assert f'href="{other_name}"' in html

    run()
    original = mapping()
    home = (base / "public/index.html").read_bytes()

    # Simulate an existing deployment with a legacy manifest and no URL table.
    with database(db_path) as db:
        db.execute("DROP TABLE article_url_bindings")
    manifest_path = base / "data/generated_pages.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["pages"] = [{"filename": row["filename"], "title": row["title"]}
                         for row in manifest["pages"]]
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    keywords.write_text("added\nsecond\nfirst\nother\n", encoding="utf-8")
    run()
    assert mapping() == original
    check_links()

    for text in ["only-new-keyword\n", "", "x\ny\nz\nfirst\n"]:
        keywords.write_text(text, encoding="utf-8")
        run()
        assert mapping() == original
        check_links()
    (base / "public" / original[3]).unlink()
    run()
    assert mapping() == original
    assert (base / "public" / original[3]).is_file()

    with database(db_path) as db:
        db.execute("INSERT INTO articles VALUES (9,'News 9','<p>Body 9</p>',"
                   "'vi','https://source.test/9')")
    run()
    assert all(mapping()[key] == value for key, value in original.items())
    ninth = mapping()[9]
    keywords.write_text("another\n", encoding="utf-8")
    run()
    assert mapping()[9] == ninth
    check_links()
    assert (base / "public/index.html").read_bytes() == home

    # A changed source with a reused ID must fail before any HTML is overwritten.
    snapshot = {file.name: file.read_bytes() for file in (base / "public").glob("*.html")}
    with database(db_path) as db:
        db.execute("UPDATE articles SET source_url='https://different.test/1' WHERE id=1")
    assert b"identity mismatch" in run(success=False)
    assert snapshot == {file.name: file.read_bytes() for file in (base / "public").glob("*.html")}
    with database(db_path) as db:
        db.execute("UPDATE articles SET source_url='https://source.test/1' WHERE id=1")

    # Recover from unambiguous existing HTML if an old manifest was lost.
    manifest_path.unlink()
    with database(db_path) as db:
        db.execute("DROP TABLE article_url_bindings")
    run()
    assert all(mapping()[key] == value for key, value in original.items())

    # Ambiguous old files must not result in choosing a new random URL.
    manifest_path.unlink()
    with database(db_path) as db:
        db.execute("DROP TABLE article_url_bindings")
    shutil.copy(base / "public" / original[1], base / "public/ambiguous-1.html")
    assert b"Multiple old URLs" in run(success=False)
    with database(db_path) as db:
        assert db.execute("SELECT COUNT(*) FROM article_url_bindings").fetchone()[0] == 0

print("PASS: legacy migration, keyword append/reorder/removal, new articles, missing HTML recovery,")
print("stable homepage, matching sitemap/internal links, ID reuse rejection and ambiguous migration rollback")

"""Test pagination and streaming generation under 128 MB with isolated data."""
import json
import re
import shutil
import sqlite3
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

root = Path(__file__).resolve().parents[1]
php = root / ".dbg/php/php.exe"
command = [str(php), "-n", "-d", f'extension_dir="{php.parent / "ext"}"',
           "-d", "extension=mbstring", "-d", "extension=pdo_sqlite",
           "-d", "memory_limit=128M"]

with tempfile.TemporaryDirectory() as temporary:
    base = Path(temporary)
    (base / "admin/templates").mkdir(parents=True)
    (base / "data").mkdir()
    for name in ["index.php", "generate.php", "anchor_store.php"]:
        shutil.copy(root / "admin" / name, base / "admin" / name)
    (base / "admin/config.php").write_text(
        "<?php define('BASE_DIR',dirname(__DIR__));define('OUTPUT_DIR',BASE_DIR.'/public');"
        "define('DB_PATH',BASE_DIR.'/data/seo_data.db');define('SITE_URL','https://example.test');"
        "$seo_config=[];", encoding="utf-8")
    (base / "admin/templates/vi_test.html").write_text(
        '<html><head><style>body{color:black}</style><title>{seo_title}</title>'
        '<meta name="description" content="{seo_description}"></head>'
        '<body><h1>{article_title}</h1>{article_content}</body></html>', encoding="utf-8")
    connection = sqlite3.connect(base / "data/seo_data.db")
    try:
        connection.execute("CREATE TABLE articles(id INTEGER PRIMARY KEY,title TEXT,content TEXT,"
                           "language TEXT,source_url TEXT,created_at TEXT)")
        body = "<p>" + "long news content " * 62000 + "</p>"
        for number in range(1, 181):
            connection.execute("INSERT INTO articles VALUES(?,?,?,?,?,?)",
                               (number, f"News {number}", body, "vi",
                                f"https://source.test/{number}", "2026-10-17"))
        connection.commit()
        assert connection.execute("SELECT SUM(length(content)) FROM articles").fetchone()[0] > 128 * 1048576
    finally:
        connection.close()

    def run(code, success=True):
        result = subprocess.run(command + ["-r", code], capture_output=True, timeout=240)
        output = (result.stdout + result.stderr).decode("utf-8", errors="replace")
        if success:
            assert result.returncode == 0 and "Warning" not in output and "Fatal error" not in output, output
        return result, output

    config = (base / "admin/config.php").as_posix()
    # The former full-body read must fail on the very same fixture and limit.
    result, output = run(f"require '{config}';$db=new PDO('sqlite:'.DB_PATH);"
                         "$all=$db->query('SELECT * FROM articles')->fetchAll(PDO::FETCH_ASSOC);", False)
    assert result.returncode != 0 and "Allowed memory size" in output
    index = (base / "admin/index.php").as_posix()
    for page, expected_page, expected_ids in [
        (1, 1, list(range(180, 130, -1))),
        (2, 2, list(range(130, 80, -1))),
        (4, 4, list(range(30, 0, -1))),
        (999, 4, list(range(30, 0, -1))),
        (-1, 1, list(range(180, 130, -1))),
        ("not-a-page", 1, list(range(180, 130, -1))),
        (["2"], 1, list(range(180, 130, -1))),
    ]:
        _, output = run(f"$_GET=json_decode('{json.dumps({'page': page})}',true);require '{index}';")
        assert [int(value) for value in re.findall(r"<td>(\d+)</td>", output)] == expected_ids
        assert f"{expected_page} / 4" in output and "180" in output
        assert "long news content" not in output

    generate = (base / "admin/generate.php").as_posix()
    _, output = run(f"require '{generate}';")
    assert output.count("[成功]") == 100
    peak = float(re.search(r"PHP 峰值内存：([0-9.]+) MB", output).group(1))
    assert peak < 128
    manifest = json.loads((base / "data/generated_pages.json").read_text(encoding="utf-8"))
    assert len(manifest["pages"]) == 180
    assert len(list(ET.parse(base / "public/sitemap.xml").iterfind(
        ".//{http://www.sitemaps.org/schemas/sitemap/0.9}loc"))) == 181
    logs = list((base / "data/generation_logs").glob("*.log"))
    assert len(logs) == 1
    assert logs[0].read_text(encoding="utf-8").count("[成功]") == 180
    page = (base / "public/news-180-180.html").read_text(encoding="utf-8")
    assert f'content="{body[3:-4].strip()}"' in page
    assert (base / "public/index.html").read_bytes() == (base / "public/news-180-180.html").read_bytes()
    (base / "data/descriptions_vi.txt").write_text("Short custom description\n", encoding="utf-8")
    _, output = run(f"require '{generate}';")
    assert len(list((base / "data/generation_logs").glob("*.log"))) == 2
    assert logs[0].read_text(encoding="utf-8").count("[成功]") == 180
    assert 'content="Short custom description"' in (base / "public/news-180-180.html").read_text(encoding="utf-8")
    _, batch = run(f"require '{config}';require '{(base / 'admin/anchor_store.php').as_posix()}';"
                   "$db=new PDO('sqlite:'.DB_PATH);anchorSchema($db);"
                   "echo anchorCreateBatch($db,'" + "a" * 64 +
                   "','External guide','https://outside.test/guide',2,OUTPUT_DIR);")
    _, output = run(f"$anchor_only_batch_id='{batch}';require '{generate}';")
    assert output.count("[成功]") == 2
    assert len(list((base / "data/anchor_exports").glob("*.txt"))) == 1
    assert len(json.loads((base / "data/generated_pages.json").read_text(encoding="utf-8"))["pages"]) == 180
    _, output = run(f"$anchor_only_batch_id='{batch}';require '{generate}';")
    assert "[成功]" not in output
    assert len(list((base / "data/anchor_exports").glob("*.txt"))) == 1
    print(f"PASS: >128 MB body fixture, old read fails, pagination and full generation pass at 128M; peak {peak} MB")
    print("PASS: description fallback/custom library, sitemap, homepage, bounded UI, unique logs and anchor batches")

import sqlite3
import datetime
import xml.etree.ElementTree as ET
from xml.dom import minidom
import os
import re
import hashlib
import json

# ================= 动态路径配置 =================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# 数据库路径
DB_PATH = os.path.join(BASE_DIR, '..', 'data', 'seo_data.db')
# Sitemap 输出路径
PUBLIC_DIR = os.path.abspath(os.path.join(BASE_DIR, '..', 'public'))
SITEMAP_PATH = os.path.join(PUBLIC_DIR, 'sitemap.xml')
MANIFEST_PATH = os.path.join(BASE_DIR, '..', 'data', 'generated_pages.json')
# 关键词库路径
KEYWORDS_PATH_PT = os.path.join(BASE_DIR, '..', 'data', 'keywords_pt.txt')

# 你的网站根域名 (必须以 http 或 https 开头，不要以斜杠结尾)
SITE_URL = "http://facegfx.com/yuenan/googleseo/public"
# ============================================

def generate_slug(text):
    """将关键词转换为 URL Slug (与 PHP 端算法一致)"""
    text = text.lower()
    
    # 替换越南语/葡萄牙语等特殊字符为普通英文字母
    unwanted_chars = {
        'š':'s', 'ž':'z', 'à':'a', 'á':'a', 'â':'a', 'ã':'a', 'ä':'a', 'å':'a', 'æ':'a', 'ç':'c',
        'è':'e', 'é':'e', 'ê':'e', 'ë':'e', 'ì':'i', 'í':'i', 'î':'i', 'ï':'i', 'ð':'o', 'ñ':'n', 
        'ò':'o', 'ó':'o', 'ô':'o', 'õ':'o', 'ö':'o', 'ø':'o', 'ù':'u', 'ú':'u', 'û':'u', 'ý':'y', 
        'þ':'b', 'ÿ':'y', 'đ':'d', 'ă':'a', 'ơ':'o', 'ư':'u'
    }
    
    for k, v in unwanted_chars.items():
        text = text.replace(k, v)
        
    text = re.sub(r'[^a-z0-9]+', '-', text)
    return text.strip('-')

def get_deterministic_index(string_key, max_count):
    """确定性算法，确保 Sitemap 和 PHP 生成的关键词/URL 一致"""
    if max_count <= 0: return 0
    hash_obj = hashlib.md5(string_key.encode('utf-8')).hexdigest()
    num = int(hash_obj[:8], 16)
    return num % max_count

def load_keywords(lang):
    """加载关键词库"""
    kw_path = os.path.join(BASE_DIR, '..', 'data', f'keywords_{lang}.txt')
    if os.path.exists(kw_path):
        with open(kw_path, 'r', encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip()]
    return []

def generate_sitemap():
    """Only list files published by the PHP generator, never guessed URLs."""
    try:
        if not os.path.isfile(MANIFEST_PATH):
            print("Sitemap: no generated-page manifest; run the PHP generator first.")
            return
        with open(MANIFEST_PATH, encoding="utf-8") as handle:
            manifest = json.load(handle)
        site_url = manifest["site_url"].rstrip("/")
        filenames = ["index.html"] + [entry["filename"] for entry in manifest["pages"]]
        filenames = list(dict.fromkeys(
            name for name in filenames
            if re.fullmatch(r"[a-z0-9-]+\.html", name)
            and os.path.isfile(os.path.join(PUBLIC_DIR, name))
        ))
        urlset = ET.Element("urlset", xmlns="http://www.sitemaps.org/schemas/sitemap/0.9")
        for filename in filenames:
            url_element = ET.SubElement(urlset, "url")
            ET.SubElement(url_element, "loc").text = f"{site_url}/{filename}"
        ET.ElementTree(urlset).write(SITEMAP_PATH + ".tmp", encoding="utf-8", xml_declaration=True)
        os.replace(SITEMAP_PATH + ".tmp", SITEMAP_PATH)
        print(f"Sitemap: published {len(filenames)} existing pages to {SITEMAP_PATH}")
    except Exception as e:
        print(f"Sitemap failed: {e}")
        raise

if __name__ == "__main__":
    generate_sitemap()

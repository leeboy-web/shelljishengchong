import requests
from bs4 import BeautifulSoup
import sqlite3
import datetime
import time
import os
import urllib.parse
import uuid
import generate_sitemap
from collections import deque
import json
import re
import xml.etree.ElementTree as ET
import sys

# ================= 动态路径配置 =================
# 获取当前脚本所在目录
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# 数据库路径 (指向 ../data/seo_data.db)
DB_PATH = os.path.join(BASE_DIR, '..', 'data', 'seo_data.db')
# 图片本地保存目录 (指向 ../public/uploads/)
UPLOAD_DIR = os.path.join(BASE_DIR, '..', 'public', 'uploads')

# ================= 爬虫目标配置 =================
# 目标语言标识（如葡萄牙语 pt，越南语 vi）
LANGUAGE = 'vi'
# 目标采集列表页 (请替换为实际要采集的网站)
TARGET_LIST_URL = "https://nongnghiephuuco.vn/" 
# CSS选择器配置 (根据你采集的目标网站调整)
SELECTOR_LINK = "a.article-link"  # 列表页中文章链接的选择器
SELECTOR_TITLE = "h1.article-detail-title"   # 详情页中标题的选择器
SELECTOR_CONTENT = "div.nnhc-detail-content" # 详情页中正文的选择器
MAX_ARTICLES_PER_RUN = 100  # 包括相关文章补采；避免单次无限抓取
SOURCES_PATH = os.path.join(BASE_DIR, 'sources.json')
LIMITS_PATH = os.path.join(BASE_DIR, 'limits.json')

def article_limit():
    if not os.path.isfile(LIMITS_PATH):
        return 5000
    with open(LIMITS_PATH, encoding="utf-8") as handle:
        limit = json.load(handle).get("max_total_articles")
    if type(limit) is not int or limit < 1:
        raise ValueError("max_total_articles must be a positive integer")
    return limit

def limit_reached(conn, limit):
    return conn.execute("SELECT COUNT(*) FROM articles").fetchone()[0] >= limit

# 伪装浏览器请求头
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'
}
# ============================================

def init_db():
    """初始化轻量级数据库 SQLite"""
    # 确保 data 和 uploads 目录存在
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    # 增加 timeout 防止 database is locked
    conn = sqlite3.connect(DB_PATH, timeout=20)
    cursor = conn.cursor()
    # 增加 WAL 模式，允许多个进程同时读写
    cursor.execute('PRAGMA journal_mode=WAL;')
    # 创建文章表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS articles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            content TEXT,
            language TEXT,
            source_url TEXT UNIQUE,
            created_at DATETIME
        )
    ''')
    conn.commit()
    return conn

def init_queue(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS crawl_queue (
        source TEXT, url TEXT, attempts INTEGER DEFAULT 0,
        PRIMARY KEY(source, url))""")
    conn.execute("""CREATE TABLE IF NOT EXISTS crawl_progress (
        source TEXT PRIMARY KEY, next_page INTEGER DEFAULT 2)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS crawl_sitemaps (
        source TEXT, url TEXT, done INTEGER DEFAULT 0,
        PRIMARY KEY(source, url))""")
    conn.commit()

def enqueue(conn, source, urls):
    conn.executemany("INSERT OR IGNORE INTO crawl_queue(source,url) VALUES (?,?)",
                     ((source["name"], url) for url in urls))
    conn.commit()

def discover_history(conn, source):
    """Persist archive discovery so later runs continue rather than restarting."""
    name = source["name"]
    template = source.get("list_page_template")
    if template:
        conn.execute("INSERT OR IGNORE INTO crawl_progress(source) VALUES (?)", (name,))
        conn.commit()
        page = conn.execute("SELECT next_page FROM crawl_progress WHERE source=?", (name,)).fetchone()[0]
        for _ in range(source.get("list_pages_per_run", 5)):
            time.sleep(source.get("request_delay", 2))
            archive = dict(source, list_url=template.format(page=page))
            urls = fetch_article_list(archive)
            if not urls:
                break
            enqueue(conn, source, urls)
            print(f"[{name}] archive page={page}, links={len(urls)}", flush=True)
            page += 1
            conn.execute("UPDATE crawl_progress SET next_page=? WHERE source=?", (page, name))
            conn.commit()
    roots = source.get("sitemap_urls", [])
    conn.executemany("INSERT OR IGNORE INTO crawl_sitemaps(source,url) VALUES (?,?)",
                     ((name, url) for url in roots))
    # Revisit indexes to discover newly published sitemap files.
    for root in roots:
        conn.execute("UPDATE crawl_sitemaps SET done=0 WHERE source=? AND url=?", (name, root))
    conn.commit()
    for _ in range(source.get("sitemap_files_per_run", 5)):
        row = conn.execute("SELECT url FROM crawl_sitemaps WHERE source=? AND done=0 ORDER BY rowid LIMIT 1",
                           (name,)).fetchone()
        if not row:
            break
        url = row[0]
        try:
            if urllib.parse.urlsplit(url).hostname not in source["allowed_hosts"]:
                raise ValueError("Sitemap host not allowed")
            time.sleep(source.get("request_delay", 2))
            response = requests.get(url, headers=HEADERS, timeout=25)
            response.raise_for_status()
            if urllib.parse.urlsplit(response.url).hostname not in source["allowed_hosts"]:
                raise ValueError("Sitemap redirect host not allowed")
            tree = ET.fromstring(response.content)
            locations = [node.text.strip() for node in tree.iter()
                         if node.tag.rsplit("}", 1)[-1] == "loc" and node.text]
            if tree.tag.rsplit("}", 1)[-1] == "sitemapindex":
                conn.executemany("INSERT OR IGNORE INTO crawl_sitemaps(source,url) VALUES (?,?)",
                                 ((name, item) for item in locations
                                  if urllib.parse.urlsplit(item).hostname in source["allowed_hosts"]))
            else:
                enqueue(conn, source, (normalized for item in locations
                        if (normalized := normalize_article_url(item, url, source))))
            conn.execute("UPDATE crawl_sitemaps SET done=1 WHERE source=? AND url=?", (name, url))
            conn.commit()
            print(f"[{name}] sitemap locations={len(locations)}: {url}", flush=True)
        except Exception as error:
            conn.rollback()
            print(f"[{name}] sitemap failed: {url}: {error}", flush=True)
            break

def default_source():
    return {
        "name": "legacy", "language": LANGUAGE, "list_url": TARGET_LIST_URL,
        "allowed_hosts": [urllib.parse.urlsplit(TARGET_LIST_URL).hostname],
        "link_selector": SELECTOR_LINK, "title_selector": SELECTOR_TITLE,
        "content_selector": SELECTOR_CONTENT, "article_path_pattern": r"^/.*\.html$",
        "max_articles": MAX_ARTICLES_PER_RUN, "request_delay": 2,
    }

def load_sources():
    with open(SOURCES_PATH, encoding="utf-8") as handle:
        sources = json.load(handle)
    for source in sources:
        for key in ("name", "language", "list_url", "allowed_hosts", "link_selector",
                    "title_selector", "content_selector", "article_path_pattern"):
            if not source.get(key):
                raise ValueError(f"Missing source configuration: {key}")
        re.compile(source["article_path_pattern"])
        if int(source.get("max_articles", 100)) < 1 or float(source.get("request_delay", 2)) < 1:
            raise ValueError("Source limits must be positive; delay must be at least one second")
    return [source for source in sources if source.get("enabled", True)]

def fetch_article_list(source=None):
    """获取文章链接列表"""
    source = source or default_source()
    try:
        response = requests.get(source["list_url"], headers=HEADERS, timeout=20)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, 'html.parser')
        links = soup.select(source["link_selector"])
        return list(dict.fromkeys(
            url for link in links
            if (url := normalize_article_url(link.get('href'), response.url, source))
        ))
    except Exception as e:
        print(f"获取列表失败: {e}")
        return []

def normalize_article_url(href, base_url, source=None):
    """Only follow news HTML pages on the configured source host."""
    if not href:
        return None
    source = source or default_source()
    url = urllib.parse.urljoin(base_url, href.strip())
    parts = urllib.parse.urlsplit(url)
    if (parts.scheme not in ("http", "https") or
            parts.hostname not in source["allowed_hosts"] or
            not re.fullmatch(source["article_path_pattern"], parts.path)):
        return None
    return urllib.parse.urlunsplit((parts.scheme, parts.netloc, parts.path, "", ""))

def content_article_urls(content, source_url, source=None):
    """Cover both related cards and other-news lists in stored content."""
    soup = BeautifulSoup(content, "html.parser")
    return list(dict.fromkeys(
        url for link in soup.select("a[href], a[attr-href]")
        if (url := normalize_article_url(link.get("href") or link.get("attr-href"), source_url, source))
    ))

def collect_articles(conn, source=None):
    source = source or default_source()
    limit = article_limit()
    if limit_reached(conn, limit):
        print(f"全站文章已达到上限 {limit}，停止新增采集。", flush=True)
        return 0
    init_queue(conn)
    # Revisit links in existing records, including news no longer on the homepage.
    stored = conn.execute(
        "SELECT source_url, content FROM articles WHERE language=?", (source["language"],)
    )
    known = set()
    enqueue(conn, source, fetch_article_list(source))
    for source_url, content in stored:
        if urllib.parse.urlsplit(source_url).hostname in source["allowed_hosts"]:
            known.add(source_url)
            enqueue(conn, source, content_article_urls(content, source_url, source))
    discover_history(conn, source)
    conn.execute("""DELETE FROM crawl_queue WHERE source=? AND
                    url IN (SELECT source_url FROM articles)""", (source["name"],))
    conn.commit()
    queue = deque(row[0] for row in conn.execute(
        "SELECT url FROM crawl_queue WHERE source=? AND attempts<3 ORDER BY attempts,rowid LIMIT ?",
        (source["name"], source.get("max_articles", 100))))
    print(f"[{source['name']}] queued for this run={len(queue)}", flush=True)
    visited = set()
    attempted = 0
    saved = 0
    while queue and attempted < source.get("max_articles", 100):
        if limit_reached(conn, limit):
            print(f"全站文章已达到上限 {limit}，停止新增采集。", flush=True)
            break
        url = queue.popleft()
        if url in visited or url in known:
            continue
        visited.add(url)
        attempted += 1
        print(f"[{source['name']}] article {attempted}/{source.get('max_articles', 100)}: {url}", flush=True)
        if scrape_article(url, conn, source):
            saved += 1
            known.add(url)
            row = conn.execute(
                "SELECT content FROM articles WHERE source_url=?", (url,)
            ).fetchone()
            links = content_article_urls(row[0], url, source)
            enqueue(conn, source, links)
            queue.extend(links)
            conn.execute("DELETE FROM crawl_queue WHERE source=? AND url=?", (source["name"], url))
        else:
            conn.execute("UPDATE crawl_queue SET attempts=attempts+1 WHERE source=? AND url=?",
                         (source["name"], url))
        conn.commit()
        time.sleep(source.get("request_delay", 2))
    remaining = conn.execute("SELECT COUNT(*) FROM crawl_queue WHERE source=? AND attempts<3",
                             (source["name"],)).fetchone()[0]
    print(f"[{source['name']}] attempted={attempted}, saved={saved}, pending={remaining}", flush=True)
    print("Run the PHP generator after collection to publish the new local links.")
    return saved

def scrape_article(url, conn, source=None):
    """抓取单篇文章并存入数据库"""
    # 每次抓取重新获取游标并设置超时，防止游标死锁
    source = source or default_source()
    limit = article_limit()
    if limit_reached(conn, limit):
        return False
    cursor = conn.cursor()
    # 检查是否已经采集过
    cursor.execute("SELECT id FROM articles WHERE source_url=?", (url,))
    if cursor.fetchone():
        print(f"已存在，跳过: {url}")
        return False

    try:
        response = requests.get(url, headers=HEADERS, timeout=10)
        response.raise_for_status()
        if normalize_article_url(response.url, url, source) is None:
            raise ValueError("Article redirected outside the configured source")
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # 提取标题和内容
        title_el = soup.select_one(source["title_selector"])
        content_el = soup.select_one(source["content_selector"])
        
        if not title_el or not content_el:
            print(f"❌ 解析失败 (选择器未匹配到内容): {url}")
            return False
            
        title = title_el.text.strip()
        for node in content_el.select("script, iframe, form"):
            node.decompose()
        
        # ================= 图片本地化处理 =================
        images = content_el.find_all('img')
        print(f"[{source['name']}] parsed title={title}; images={len(images)}", flush=True)
        for img_index, img in enumerate(images, 1):
            # 优先获取懒加载图片的真实地址，否则获取 src
            img_url = img.get('data-src') or img.get('data-original') or img.get('src')
            if not img_url:
                continue
                
            # 将相对路径转换为绝对路径
            img_url = urllib.parse.urljoin(url, img_url)
            
            try:
                print(f"[{source['name']}] image {img_index}/{len(images)}", flush=True)
                # 下载图片
                time.sleep(source.get("request_delay", 2))
                img_resp = requests.get(img_url, headers={**HEADERS, "Referer": url}, timeout=10)
                if img_resp.status_code == 200 and img_resp.headers.get("Content-Type", "").startswith("image/"):
                    # 获取后缀名，如果获取不到默认用 .jpg
                    ext = os.path.splitext(urllib.parse.urlparse(img_url).path)[1]
                    if not ext or len(ext) > 5:
                        ext = '.jpg'
                    
                    # 生成随机文件名并保存
                    filename = str(uuid.uuid4().hex)[:12] + ext
                    filepath = os.path.join(UPLOAD_DIR, filename)
                    with open(filepath, 'wb') as f:
                        f.write(img_resp.content)
                    
                    # 将 HTML 源码中的图片路径替换为本地相对路径 (因为网页在 public 目录下，所以直接用 uploads/...)
                    img['src'] = f"uploads/{filename}"
                    
                    # 清除可能导致前端懒加载失败或冲突的属性
                    for attr in ['data-src', 'data-original', 'srcset', 'data-srcset', 'lazyload']:
                        if attr in img.attrs:
                            del img[attr]
            except Exception as e:
                print(f"⚠️ 图片下载失败，跳过: {img_url} ({e})")
        # ==================================================
        
        # 提取内容的 HTML 源码，保留段落格式
        content = content_el.decode_contents().strip()
        
        # 存入数据库 (增加重试机制)
        max_retries = 3
        for attempt in range(max_retries):
            try:
                # Serialize the final count and insert across concurrent collectors.
                conn.execute("BEGIN IMMEDIATE")
                if limit_reached(conn, limit):
                    conn.rollback()
                    print(f"全站文章已达到上限 {limit}，不再入库。", flush=True)
                    return False
                if conn.execute("SELECT 1 FROM articles WHERE source_url=?", (url,)).fetchone():
                    conn.rollback()
                    return False
                cursor.execute('''
                    INSERT INTO articles (title, content, language, source_url, created_at)
                    VALUES (?, ?, ?, ?, ?)
                ''', (title, content, source["language"], url, datetime.datetime.now()))
                conn.commit()
                print(f"✅ 成功采集并保存: {title}")
                return True
            except sqlite3.OperationalError as e:
                conn.rollback()
                if "locked" in str(e) and attempt < max_retries - 1:
                    print(f"⚠️ 数据库锁定，正在重试 ({attempt+1}/{max_retries})...")
                    time.sleep(2)
                else:
                    raise e
    except Exception as e:
        print(f"❌ 采集失败 {url}: {e}")
        return False

if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(line_buffering=True)
    print(f"开始执行采集任务 - 语言: {LANGUAGE} - 时间: {datetime.datetime.now()}")
    db_conn = init_db()
    try:
        has_new_articles = False
        for source in load_sources():
            if limit_reached(db_conn, article_limit()):
                print(f"全站文章已达到上限 {article_limit()}，本次任务退出。", flush=True)
                break
            print(f"Starting source: {source['name']} ({source['list_url']})")
            try:
                has_new_articles = collect_articles(db_conn, source) > 0 or has_new_articles
            except Exception as error:
                db_conn.rollback()
                print(f"[{source['name']}] failed: {error}")
    finally:
        db_conn.close()
    print("采集任务执行完毕。")
    
    # 在采集完成后自动生成 Sitemap
    if has_new_articles:
        print("检测到有新内容入库，正在触发 Sitemap 实时更新...")
        generate_sitemap.generate_sitemap()
    else:
        print("本次没有采集到新内容，跳过 Sitemap 更新。")
